%%  SUSPENSION Q1 TOOLKIT — v2 (UNIFIED, AUDITED, ROBUSTNESS-AWARE BENCHMARK)
%  =========================================================================
%  What changed vs. the previous "Option A" script (reviewer-driven fixes):
%
%  [1] ONE SIMULATION ENVIRONMENT.  All controllers (Passive, PID, Fuzzy,
%      FPID, LQR, L1-Adaptive) are re-simulated here with the SAME plant,
%      road, sensor delay, actuator (saturation + rate limit + lag) and
%      metrics.  The old Simulink CSV logs are kept only as a "legacy"
%      data set that is AUDITED, not mixed into the ranking.
%  [2] DATA-CONSISTENCY AUDIT of the legacy logs: acceleration is rebuilt
%      from logged zs, zu, velocity and force through the quarter-car
%      equation; residuals and a force-authority check are reported
%      (legacy_data_audit.csv).  A physically inconsistent log is flagged.
%  [3] NO SILENT ZERO-FILLING / TRUNCATION.  Every signal is interpolated
%      on a common time grid; metrics use only samples where ALL needed
%      signals exist (window length and coverage are reported).
%  [4] REALISTIC ACTUATOR.  F_max = 1500 N (configurable, same for all).
%      Saturation is measured for every controller (Sat_pct).
%  [5] BUG FIXES in metrics:
%        - tire deflection is always  zu - zr  (the old code used zu for the
%          baselines);
%        - ISO 2631-1 Wk is applied in the frequency domain with the exact
%          standard transfer functions (verified against the Wk table);
%          the old double-pass filtfilt squared the weighting;
%        - band RMS uses Parseval on the FFT (bands partition the energy);
%          the old MODWT code counted the detail band twice;
%        - VDV and MTVV are added (transient excitations, ISO 2631-1).
%  [6] L1 DONE PROPERLY: piecewise-constant adaptation law with projection,
%      state predictor driven by the MEASURED actuator force, matched +
%      unmatched uncertainty channels, first-order C(s) filter, and an
%      ablation against its own LQR baseline (controller "LQR").
%  [7] FAIR TUNING PROTOCOL: every tunable controller is tuned with the same
%      optimiser, the same evaluation budget and the same cost function on
%      random ISO-8608 TRAINING roads (nominal + perturbed plants) that are
%      different from the TEST roads.
%  [8] ROBUSTNESS STUDY: one-at-a-time parametric / delay / actuator
%      scenarios and a Monte-Carlo study (+-20 % ms, ks, cs, kt, random
%      delay) -> mean, std, worst case, failures, paired win-rate vs LQR.
%  [9] Pareto front on (ISO aw, tire RMS, force RMS) per road, plus the
%      comfort/handling-only front; figures in Vehicle System Dynamics
%      artwork style (600 dpi PNG + vector PDF).
%
%  REQUIREMENTS: MATLAB R2018b+, Control System Toolbox (lqr, ss, impulse).
%  Optional: Global Optimization Toolbox (gamultiobj) for NSGA-II.
%  Put this script in the folder with the 6 CSV files (optional: the script
%  runs without them, using synthetic deterministic roads).
%
%  HONEST FRAMING FOR THE PAPER: PID/Fuzzy/FPID/LQR structures and gains are
%  re-implemented and tuned here (see "CONTROLLER DEFINITIONS" below).  If
%  you must reproduce your own Simulink gains, overwrite THETA0 and set
%  DO_TUNING = false.
%
%  Usage:  >> suspension_q1_v2_unified
%  =========================================================================

clear; clc; close all;

%% ===================== 0. CONFIGURATION ==================================
CSV_FILES = struct( ...
  'acceleration',   'acceleration.csv', ...
  'body_position',  'Body position.csv', ...
  'body_velocity',  'body velocity.csv', ...
  'force',          'force.csv', ...
  'tire_position',  'tire position.csv', ...
  'vert_error',     'vertical displacement error.csv');

USE_LEGACY_DATA = true;     % audit + fixed metrics on the old Simulink logs
DO_TUNING       = true;     % false -> use THETA0 as shipped
TUNE_MAXFEV     = 60;       % equal function-evaluation budget per controller
N_MC            = 30;       % Monte-Carlo samples
RUN_NSGA2       = false;    % optional multi-objective tuning of the L1 filter
T_ISO           = 10;       % duration of the random-road test (s)
SEED_TEST       = 21;       % seed of the random TEST road (train: 11, 12)

CTRL_ORDER = {'Passive','PID','Fuzzy','FPID','LQR','L1_Adaptive'};
ROAD_ORDER = {'Step','Stairs','VariableFreq','SineWave','Bump','ISO_C'};

% Plant (quarter car, Table I of the paper)
params = struct('ms',400,'mu',53,'ks',20800,'cs',4800,'kt',80000, ...
                'dt',1e-3,'v',20,'g',9.81, ...
                'F_max',1500,'dF_max',5e4,'tau_a',0.020,'tau_d',0.005);

% Controller parameters are stored as log10-scaled vectors (see
% controller_init for the meaning of each entry).  Defaults = result of the
% tuning protocol of section 3 (re-tuned at run time when DO_TUNING = true).
THETA0 = struct( ...
  'Passive',     0, ...
  'PID',         [ 2.447  2.827 -2.889], ...         % log10 [Kp Ki Kd] on body acceleration
  'Fuzzy',       [-0.098 -0.533  2.740], ...         % log10 [S_a S_v S_u]
  'FPID',        [ 2.525  2.684 -2.788  1.282  0.754], ... % log10 [Kp Ki Kd], gain multipliers
  'LQR',         [ 4.510  4.421], ...                % log10 [rho_susp rho_tire]
  'L1_Adaptive', [ 1.418 -1.530]);                   % log10 [omega_c (rad/s), bound/F_max]

fprintf('=== Suspension toolkit v2: unified benchmark ===\n');

%% ===================== 1. LEGACY DATA (AUDIT ONLY) =======================
have_legacy = false;  legacy = struct();
files_ok = all(cellfun(@(f) exist(f,'file')==2, struct2cell(CSV_FILES)));
if USE_LEGACY_DATA && files_ok
  fprintf('\n--- Step 1: loading legacy CSV logs ---\n');
  legacy = load_legacy(CSV_FILES);
  have_legacy = true;
elseif USE_LEGACY_DATA
  warning('Legacy CSV files not found: continuing with synthetic roads only.');
end

%% ===================== 2. ROAD SET (TEST) ================================
roads = struct();
for r = 1:numel(ROAD_ORDER)
  nm = ROAD_ORDER{r};
  if strcmp(nm,'ISO_C')
    roads.(nm) = iso_road_profile('C', SEED_TEST, T_ISO, params);
  elseif have_legacy && isfield(legacy.road_inputs, nm)
    ri = legacy.road_inputs.(nm);
    roads.(nm) = resample_road(ri.t, ri.zr, params.dt);
  else
    roads.(nm) = synthetic_road(nm, 16, params.dt);
  end
end

%% ===================== 3. FAIR TUNING PROTOCOL ===========================
fprintf('\n--- Step 3: tuning protocol (same optimiser / budget / cost) ---\n');
zB = iso_road_profile('B', 11, 8, params).zr;      % training road 1
zD = iso_road_profile('D', 12, 8, params).zr;      % training road 2
scen = struct('zr',{zB, zD, zB}, 'p', {params, ...
   perturb_params(params, struct('ms',1.2,'ks',0.8,'cs',0.7,'kt',0.85)), ...
   perturb_params(params, struct('ms',0.8,'ks',1.2,'cs',1.2,'kt',1.1))});
base = cell(1, numel(scen));
for i = 1:numel(scen)
  base{i} = quick_metrics(simulate_loop('Passive',0,scen(i).zr,scen(i).p,params,[]), scen(i).p);
end

theta = THETA0;  Jfinal = struct();
if DO_TUNING
  [theta.LQR, Jfinal.LQR] = tune_controller('LQR', theta.LQR, scen, base, params, [], TUNE_MAXFEV);
  K_lqr = lqr_output_weighted(params, 10^theta.LQR(1), 10^theta.LQR(2));
  tune_list = {'PID','Fuzzy','FPID','L1_Adaptive'};
  for i = 1:numel(tune_list)
    kd = tune_list{i};
    [theta.(kd), Jfinal.(kd)] = tune_controller(kd, theta.(kd), scen, base, params, K_lqr, TUNE_MAXFEV);
  end
else
  K_lqr = lqr_output_weighted(params, 10^theta.LQR(1), 10^theta.LQR(2));
  for i = 2:numel(CTRL_ORDER)
    kd = CTRL_ORDER{i};
    Jfinal.(kd) = tuning_cost(kd, theta.(kd), scen, base, params, K_lqr);
  end
end
Jfinal.Passive = 1.8;                    % 1 + 0.5 + 0.3 by construction
fprintf('LQR gain K = [%.1f %.1f %.1f %.1f]\n', K_lqr);
tuned_tbl = table(CTRL_ORDER', cellfun(@(c) mat2str(theta.(c),4), CTRL_ORDER','UniformOutput',false), ...
                  cellfun(@(c) Jfinal.(c), CTRL_ORDER'), 'VariableNames', {'Controller','theta_log10','Train_cost'});
disp(tuned_tbl);  writetable(tuned_tbl, 'tuned_parameters.csv');

% L1 theory diagnostic (L1-norm of G(s) = H(s)(1-C(s)))
try
  [g1, g1_names] = l1_gain_report(params, 10^theta.L1_Adaptive(1));
  tmp = [g1_names; num2cell(g1(:))'];  fprintf('L1 diagnostic: ||G||_L1 per state = ');  fprintf('%s=%.3g  ', tmp{:});  fprintf('\n');
catch ME
  fprintf('L1 diagnostic skipped (%s)\n', ME.message);
end

%% ===================== 4. UNIFIED SIMULATION (TEST ROADS) ================
fprintf('\n--- Step 4: unified simulation, %d controllers x %d roads ---\n', numel(CTRL_ORDER), numel(ROAD_ORDER));
SIM = struct();  rows = {};
for r = 1:numel(ROAD_ORDER)
  road = ROAD_ORDER{r};  zr = roads.(road).zr;
  for c = 1:numel(CTRL_ORDER)
    ctrl = CTRL_ORDER{c};
    d = simulate_loop(ctrl, theta.(ctrl), zr, params, params, K_lqr);
    if ~isempty(d), d.t = roads.(road).t(1:numel(d.acc)); end
    SIM.(road).(ctrl) = d;
    m = compute_metrics(d, params, true(numel(zr),1));
    m.Road = road;  m.Controller = ctrl;  m.Source = 'Unified_MATLAB';
    rows{end+1,1} = m;  %#ok<SAGROW>
  end
  fprintf('  %-13s done\n', road);
end
summary = struct2table(vertcat(rows{:}));
summary = movevars(summary, {'Road','Controller','Source'}, 'Before', 1);
writetable(summary, 'results_summary_unified.csv');
disp(summary(:, {'Road','Controller','ISO_aw','RMS_acc','RMS_tire','RMS_susp','RMS_force','Peak_force','Sat_pct'}));

% improvement table (% reduction of ISO a_w vs. Passive on the same road)
imp = zeros(numel(ROAD_ORDER), numel(CTRL_ORDER));
for r = 1:numel(ROAD_ORDER)
  idxP = strcmp(summary.Road, ROAD_ORDER{r}) & strcmp(summary.Controller, 'Passive');
  for c = 1:numel(CTRL_ORDER)
    idx = strcmp(summary.Road, ROAD_ORDER{r}) & strcmp(summary.Controller, CTRL_ORDER{c});
    imp(r,c) = 100*(summary.ISO_aw(idxP) - summary.ISO_aw(idx)) / summary.ISO_aw(idxP);
  end
end
imp_tbl = array2table(imp, 'VariableNames', CTRL_ORDER, 'RowNames', ROAD_ORDER);
fprintf('\nISO 2631 a_w reduction vs Passive (%%):\n');  disp(imp_tbl);
writetable(imp_tbl, 'iso_aw_improvement_pct.csv', 'WriteRowNames', true);

%% ===================== 5. LEGACY AUDIT + FIXED LEGACY METRICS ============
audit_tbl = table();  legacy_tbl = table();
if have_legacy
  fprintf('\n--- Step 5: legacy data audit ---\n');
  [audit_tbl, legacy_tbl] = legacy_audit(legacy, params);
  writetable(audit_tbl,  'legacy_data_audit.csv');
  writetable(legacy_tbl, 'results_summary_legacy_fixed.csv');
  disp(audit_tbl(:, {'Road','Controller','Coverage_pct','Corr_acc','NRMSE_acc','Resid_force_N', ...
                     'Force_logged_N','Force_implied_N','Force_ratio','Flag'}));
  nflag = sum(~strcmp(audit_tbl.Flag, 'OK'));
  fprintf('%d of %d legacy records are flagged (INCONSISTENT / FORCE_WARNING) against the stated plant.\n', nflag, height(audit_tbl));
  fprintf(['  -> Do NOT mix these logs with the MATLAB results in a ranking; either fix the Simulink\n' ...
           '     model (units/scale of force, plant parameters) or report them only as a limitation.\n']);
end

%% ===================== 6. PARETO FRONTS ==================================
fprintf('\n--- Step 6: Pareto analysis (comfort, road holding, effort) ---\n');
ND3 = false(height(summary),1);  ND2 = false(height(summary),1);
for r = 1:numel(ROAD_ORDER)
  idx = find(strcmp(summary.Road, ROAD_ORDER{r}));
  F3 = [summary.ISO_aw(idx), summary.RMS_tire(idx), summary.RMS_force(idx)];
  F3(isnan(F3)) = Inf;
  ND3(idx) = nondominated(F3);
  ND2(idx) = nondominated(F3(:,1:2));
  fprintf('  %-13s 3-obj: %-40s | comfort-vs-handling: %s\n', ROAD_ORDER{r}, ...
          strjoin(summary.Controller(idx(ND3(idx(:))))', ','), strjoin(summary.Controller(idx(ND2(idx(:))))', ','));
end
summary.ND_3obj = ND3;  summary.ND_comfort_handling = ND2;
writetable(summary, 'results_summary_unified.csv');

if RUN_NSGA2 && exist('gamultiobj','file') == 2
  try
    fprintf('\nNSGA-II on the L1 filter/projection (ISO_C road)...\n');
    fit  = @(g) l1_multiobj(g, roads.ISO_C.zr, params, K_lqr);
    opts = optimoptions('gamultiobj','PopulationSize',24,'MaxGenerations',15,'Display','iter');
    [x_opt, f_opt] = gamultiobj(fit, 2, [], [], [], [], [0.5 -3], [2.5 0], opts);
    save('pareto_nsga_results.mat', 'x_opt', 'f_opt');
    fprintf('NSGA-II: %d Pareto-optimal L1 settings saved.\n', size(x_opt,1));
  catch ME
    fprintf('NSGA-II skipped: %s\n', ME.message);
  end
end

%% ===================== 7. ROBUSTNESS =====================================
fprintf('\n--- Step 7: robustness (one-at-a-time scenarios, ISO_C road) ---\n');
SC = { 'Nominal',            struct(); ...
       'Sprung mass +20%',   struct('ms',1.2); ...
       'Sprung mass -20%',   struct('ms',0.8); ...
       'Spring ks -20%',     struct('ks',0.8); ...
       'Spring ks +20%',     struct('ks',1.2); ...
       'Tire kt -20%',       struct('kt',0.8); ...
       'Damper fade -30%',   struct('cs',0.7); ...
       'Sensor delay 20 ms', struct('tau_d',0.020); ...
       'Actuator lag 40 ms', struct('tau_a',0.040)};
zrob = roads.ISO_C.zr;
rob_rows = {};
for s = 1:size(SC,1)
  ps  = perturb_params(params, SC{s,2});
  res = eval_all_controllers(CTRL_ORDER, theta, zrob, ps, params, K_lqr);
  awP = res{1}.aw;
  for c = 1:numel(CTRL_ORDER)
    rob_rows{end+1,1} = struct('Scenario', SC{s,1}, 'Controller', CTRL_ORDER{c}, ...
      'ISO_aw', res{c}.aw, 'Improve_pct', 100*(awP-res{c}.aw)/awP, ...
      'RMS_tire', res{c}.tire, 'RMS_susp', res{c}.susp, 'RMS_force', res{c}.rmsF, ...
      'Stable', res{c}.stable);  %#ok<SAGROW>
  end
end
rob_tbl = struct2table(vertcat(rob_rows{:}));
writetable(rob_tbl, 'robust_scenarios.csv');
piv = zeros(size(SC,1), numel(CTRL_ORDER));
for s = 1:size(SC,1)
  for c = 1:numel(CTRL_ORDER)
    piv(s,c) = rob_tbl.Improve_pct(strcmp(rob_tbl.Scenario, SC{s,1}) & strcmp(rob_tbl.Controller, CTRL_ORDER{c}));
  end
end
fprintf('ISO a_w reduction vs Passive (%%) per scenario:\n');
disp(array2table(piv, 'VariableNames', CTRL_ORDER, 'RowNames', SC(:,1)));

fprintf('\n--- Step 7b: Monte-Carlo (%d samples: +-20%% ms,ks,cs,kt; delay 5-15 ms) ---\n', N_MC);
rng(123);
mc_imp = nan(N_MC, numel(CTRL_ORDER));  mc_fail = zeros(1, numel(CTRL_ORDER));
for k = 1:N_MC
  f  = 1 + 0.2*(2*rand(1,4) - 1);
  ps = perturb_params(params, struct('ms',f(1),'ks',f(2),'cs',f(3),'kt',f(4)));
  ps.tau_d = 0.005 + 0.010*rand;
  res = eval_all_controllers(CTRL_ORDER, theta, zrob, ps, params, K_lqr);
  awP = res{1}.aw;
  for c = 1:numel(CTRL_ORDER)
    if res{c}.stable, mc_imp(k,c) = 100*(awP - res{c}.aw)/awP;
    else, mc_fail(c) = mc_fail(c) + 1; end
  end
end
iL = find(strcmp(CTRL_ORDER, 'LQR'));
mc_tbl = table(CTRL_ORDER', mean(mc_imp,1,'omitnan')', std(mc_imp,0,1,'omitnan')', ...
               median(mc_imp,1,'omitnan')', min(mc_imp,[],1)', mc_fail', ...
               100*mean(double(mc_imp > mc_imp(:,iL)), 1)', ...
  'VariableNames', {'Controller','Mean_improve_pct','Std','Median','Worst','Failures','Win_vs_LQR_pct'});
disp(mc_tbl);  writetable(mc_tbl, 'robust_montecarlo.csv');
iL1 = find(strcmp(CTRL_ORDER, 'L1_Adaptive'));
dd = mc_imp(:,iL1) - mc_imp(:,iL);
fprintf('Paired L1 - LQR improvement: mean %.2f %%, std %.2f %%, L1 better in %.0f %% of samples.\n', ...
        mean(dd,'omitnan'), std(dd,'omitnan'), 100*mean(double(dd > 0)));

%% ===================== 8. FIGURES (Vehicle System Dynamics style) ========
fprintf('\n--- Step 8: journal figures ---\n');
set(0, 'DefaultAxesFontName','Helvetica', 'DefaultAxesFontSize',8, ...
       'DefaultTextFontName','Helvetica', 'DefaultTextFontSize',9, ...
       'DefaultAxesTickDir','out', 'DefaultAxesBox','off', ...
       'DefaultAxesLineWidth',0.5, 'DefaultLineLineWidth',0.75);
W2 = 539;  W1 = 255;                              % 190 mm / 90 mm in points
labels = strrep(CTRL_ORDER, '_', ' ');
nC = numel(CTRL_ORDER);
colors  = [0.45 0.45 0.45; 0.00 0.45 0.74; 1.00 0.49 0.05; 0.84 0.15 0.16; 0.49 0.18 0.56; 0.47 0.67 0.19];
markers = {'o','s','^','d','v','p'};

% Fig 1: body acceleration time histories
fig1 = figure('Color','w','Position',[60 60 W2 640]);
for r = 1:numel(ROAD_ORDER)
  subplot(numel(ROAD_ORDER), 1, r);  hold on;  grid on;
  for c = 1:nC
    d = SIM.(ROAD_ORDER{r}).(CTRL_ORDER{c});
    if ~isempty(d), plot(d.t, d.acc, 'Color', colors(c,:), 'DisplayName', labels{c}); end
  end
  title(sprintf('Road: %s', ROAD_ORDER{r}), 'FontSize', 8);  ylabel('a_{body} (m/s^2)');
  if r == 1, legend('Location','northeast','NumColumns',6,'FontSize',7,'Box','off'); end
end
xlabel('Time (s)');  save_journal_figure(fig1, 'plot_01_acceleration_overview');

% Fig 2: improvement of ISO a_w vs passive
fig2 = figure('Color','w','Position',[60 60 W2 280]);
b = bar(imp(:,2:end), 'EdgeColor','none');  grid on;
for c = 2:nC, b(c-1).FaceColor = colors(c,:); end
set(gca, 'XTick', 1:numel(ROAD_ORDER), 'XTickLabel', ROAD_ORDER);
ylabel('ISO 2631 a_w reduction vs. passive (%)');
legend(labels(2:end), 'Location','northoutside', 'NumColumns',5, 'FontSize',7, 'Box','off');
save_journal_figure(fig2, 'plot_02_iso_improvement');

% Fig 3: Pareto (comfort vs effort) per road, non-dominated points ringed
fig3 = figure('Color','w','Position',[60 60 W2 380]);
for r = 1:numel(ROAD_ORDER)
  subplot(2,3,r);  hold on;  grid on;
  for c = 1:nC
    i = find(strcmp(summary.Road, ROAD_ORDER{r}) & strcmp(summary.Controller, CTRL_ORDER{c}));
    scatter(max(summary.RMS_force(i), 1), summary.ISO_aw(i), 36, colors(c,:), markers{c}, 'filled', 'DisplayName', labels{c});
    if summary.ND_3obj(i), scatter(max(summary.RMS_force(i),1), summary.ISO_aw(i), 90, 'k', 'o', 'LineWidth', 0.75, 'HandleVisibility','off'); end
  end
  set(gca, 'XScale','log');  title(ROAD_ORDER{r}, 'FontSize', 8);
  xlabel('RMS force (N)');  ylabel('ISO a_w (m/s^2)');
  if r == 1, legend('Location','best','FontSize',6,'Box','off'); end
end
save_journal_figure(fig3, 'plot_03_pareto');

% Fig 4: ISO a_w, Fig 5: frequency bands
fig4 = figure('Color','w','Position',[60 60 W2 380]);
panel_bars(summary, ROAD_ORDER, CTRL_ORDER, colors, 'ISO_aw', 'ISO 2631 a_w (m/s^2)');
save_journal_figure(fig4, 'plot_04_iso2631_summary');

fig5 = figure('Color','w','Position',[60 60 W2 380]);
for r = 1:numel(ROAD_ORDER)
  subplot(2,3,r);  vals = zeros(nC,3);
  for c = 1:nC
    i = find(strcmp(summary.Road, ROAD_ORDER{r}) & strcmp(summary.Controller, CTRL_ORDER{c}));
    vals(c,:) = [summary.Band1_0p5_4Hz(i), summary.Band2_4_8Hz(i), summary.Band3_8_20Hz(i)];
  end
  bb = bar(vals, 'stacked');  grid on;
  bb(1).FaceColor = [0.2 0.6 0.8];  bb(2).FaceColor = [0.9 0.6 0.2];  bb(3).FaceColor = [0.7 0.2 0.2];
  set(gca, 'XTick',1:nC, 'XTickLabel',labels, 'XTickLabelRotation',35);
  title(ROAD_ORDER{r}, 'FontSize', 8);  ylabel('Band RMS (m/s^2)');
  if r == 1, legend({'0.5-4 Hz','4-8 Hz','8-20 Hz'}, 'Location','northwest','FontSize',7,'Box','off'); end
end
save_journal_figure(fig5, 'plot_05_freq_bands');

% Fig 6: Monte-Carlo robustness
fig6 = figure('Color','w','Position',[60 60 W1*1.6 300]);  hold on;  grid on;
for c = 2:nC
  x = (c-1) + 0.12*randn(N_MC,1);
  scatter(x, mc_imp(:,c), 14, colors(c,:), 'filled', 'MarkerFaceAlpha', 0.5);
  errorbar(c-1, mean(mc_imp(:,c),'omitnan'), std(mc_imp(:,c),'omitnan'), 'k', 'LineWidth', 1, 'CapSize', 6);
end
set(gca, 'XTick',1:nC-1, 'XTickLabel',labels(2:end), 'XTickLabelRotation',25);
ylabel('ISO a_w reduction vs. passive (%)');  title(sprintf('Monte-Carlo, %d perturbed plants', N_MC), 'FontSize', 8);
save_journal_figure(fig6, 'plot_06_montecarlo');

% Fig 7: legacy force-authority audit
if have_legacy && ~isempty(audit_tbl)
  fig7 = figure('Color','w','Position',[60 60 W1 300]);  hold on;  grid on;
  ctl_l = {'PID','Fuzzy','FPID'};  cm = [colors(2,:); colors(3,:); colors(4,:)];
  for c = 1:3
    i = strcmp(audit_tbl.Controller, ctl_l{c});
    scatter(audit_tbl.Force_implied_N(i), audit_tbl.Force_logged_N(i), 40, cm(c,:), 'filled', 'DisplayName', ctl_l{c});
  end
  lim = [1 max([audit_tbl.Force_implied_N; audit_tbl.Force_logged_N; 10])*1.5];
  plot(lim, lim, 'k--', 'DisplayName', 'logged = implied');
  set(gca, 'XScale','log', 'YScale','log');
  xlabel('Force implied by acceleration change (N)');  ylabel('Force logged in Simulink (N)');
  legend('Location','southeast', 'FontSize', 7, 'Box','off');
  save_journal_figure(fig7, 'plot_07_legacy_force_audit');
end

%% ===================== 9. SAVE + WINNERS =================================
save('results_full.mat', 'summary', 'imp_tbl', 'rob_tbl', 'mc_tbl', 'mc_imp', 'theta', 'K_lqr', 'params', 'audit_tbl', 'legacy_tbl');
fprintf('\nBest controller per road by ISO a_w (unified benchmark):\n');
for r = 1:numel(ROAD_ORDER)
  i = find(strcmp(summary.Road, ROAD_ORDER{r}));  [~, j] = min(summary.ISO_aw(i));
  fprintf('  %-13s -> %s (a_w = %.4f m/s^2, %.1f %% below passive)\n', ROAD_ORDER{r}, summary.Controller{i(j)}, summary.ISO_aw(i(j)), imp(r, strcmp(CTRL_ORDER, summary.Controller{i(j)})));
end
fprintf('\n=== DONE. Files: results_summary_unified.csv, iso_aw_improvement_pct.csv, tuned_parameters.csv,\n');
fprintf('    robust_scenarios.csv, robust_montecarlo.csv, legacy_data_audit.csv, results_summary_legacy_fixed.csv,\n');
fprintf('    plot_01..07 (.png 600 dpi + .pdf), results_full.mat ===\n');

%% ===================== LOCAL FUNCTIONS ===================================

% ---------------------------------------------------------------- plant ---
function p2 = perturb_params(p, s)
%PERTURB_PARAMS  multiplicative factors, except tau_* fields (absolute values)
  p2 = p;  f = fieldnames(s);
  for i = 1:numel(f)
    if startsWith(f{i}, 'tau_'), p2.(f{i}) = s.(f{i});
    else, p2.(f{i}) = p.(f{i}) * s.(f{i}); end
  end
end

function [A, b, E] = make_plant(p)
  A = [0,          1,          0,                0;
      -p.ks/p.ms, -p.cs/p.ms,  p.ks/p.ms,        p.cs/p.ms;
       0,          0,          0,                1;
       p.ks/p.mu,  p.cs/p.mu, -(p.ks+p.kt)/p.mu, -p.cs/p.mu];
  b = [0; 1/p.ms; 0; -1/p.mu];          % actuator force (up on body, down on wheel)
  E = [0; 0; 0; p.kt/p.mu];             % road displacement input
end

function [Ad, Bd, Ed] = c2d_zoh(A, b, E, dt)
%C2D_ZOH  exact zero-order-hold discretisation of x' = Ax + b*F + E*zr
  M = zeros(6);  M(1:4,1:4) = A;  M(1:4,5) = b;  M(1:4,6) = E;
  Md = expm(M*dt);
  Ad = Md(1:4,1:4);  Bd = Md(1:4,5);  Ed = Md(1:4,6);
end

function K = lqr_output_weighted(p, rho_s, rho_t)
%LQR_OUTPUT_WEIGHTED  LQR on  J = int( a_s^2 + rho_s*(zs-zu)^2 + rho_t*zu^2 + rF*F^2 )
%  (acceleration enters through its output equation -> cross term N).
  [A, b, ~] = make_plant(p);
  C = [-p.ks/p.ms, -p.cs/p.ms, p.ks/p.ms, p.cs/p.ms];  D = 1/p.ms;
  Cs = [1 0 -1 0];  Ct = [0 0 1 0];  rF = 1e-6;
  Q = C'*C + rho_s*(Cs'*Cs) + rho_t*(Ct'*Ct);
  R = D^2 + rF;  N = C'*D;
  try
    K = lqr(A, b, Q, R, N);
  catch
    K = zeros(1,4);
  end
end

% ---------------------------------------------------------- controllers ---
function c = controller_init(kind, th, pn, K)
%CONTROLLER_INIT  controller state.  th = log10-scaled parameter vector:
%   PID/FPID : [Kp Ki Kd] acting on measured body ACCELERATION (a_s -> 0);
%              FPID adds th(4:5) = gain multipliers for "small"/"large" regime
%              of a fuzzy scheduler lambda = f(|a_s|/2, |zs_dot|/0.2)
%   Fuzzy    : Sugeno 5x5 rule base, inputs a_s/S_a and zs_dot/S_v, output S_u
%   LQR      : th = log10 [rho_susp rho_tire]
%   L1       : th = log10 [omega_c(rad/s), projection bound / F_max]
  c.kind = kind;  c.th = th;  c.dt = pn.dt;  c.ms = pn.ms;  c.Fmax = pn.F_max;
  [A, b, ~] = make_plant(pn);
  c.A2 = A(2,:);  c.I = 0;  c.aprev = 0;  c.df = 0;  c.tf = 0.01;
  switch kind
    case {'PID','FPID'}
      c.Kp = 10^th(1);  c.Ki = 10^th(2);  c.Kd = 10^th(3);
    case 'Fuzzy'
      c.Sa = 10^th(1);  c.Sv = 10^th(2);  c.Su = 10^th(3);
      c.cen = [-1 -0.5 0 0.5 1];  lv = -2:2;
      c.Ctab = -max(-2, min(2, lv(:) + lv(:)'))/2;     % rows: e, cols: de
    case 'LQR'
      c.K = lqr_output_weighted(pn, 10^th(1), 10^th(2));
    case 'L1_Adaptive'
      c.K  = K;
      wc   = 10^min(max(th(1), 0), 2.5);
      c.bnd = 10^min(max(th(2), -3), 0) * pn.F_max;     % projection operator
      c.Ad  = expm(A*c.dt);
      c.Phi = A \ (c.Ad - eye(4));
      c.b   = b;
      Bf    = [b, null(b')];                            % [matched, unmatched]
      c.Bum = Bf(:, 2:4);
      c.G   = -(Bf \ (c.Phi \ c.Ad));                   % piecewise-constant law
      c.al  = c.dt*wc / (1 + c.dt*wc);                  % C(s) = wc/(s+wc)
      c.xh  = zeros(4,1);  c.sf = 0;
  end
end

function [u, c] = controller_step(c, xd, Fh)
%CONTROLLER_STEP  xd = delayed measured state, Fh = measured actuator force
%  at the (delayed) sampling instant.
  dt = c.dt;
  switch c.kind
    case 'Passive'
      u = 0;
    case {'PID','FPID'}
      a = c.A2*xd + Fh/c.ms;                 % accelerometer reading
      f = 1;
      if strcmp(c.kind, 'FPID')
        lam = min(1, hypot(a/2.0, xd(2)/0.2)/sqrt(2));
        f = c.th(4)*(1-lam) + c.th(5)*lam;
      end
      lim = c.Fmax / max(c.Ki, 1e-9);
      c.I = max(-lim, min(lim, c.I + a*dt));              % anti-windup
      c.df = c.df + dt/(c.tf+dt) * ((a - c.aprev)/dt - c.df);   % filtered derivative
      c.aprev = a;
      u = -(f*(c.Kp*a + c.Kd*c.df) + c.Ki*c.I);
    case 'Fuzzy'
      a = c.A2*xd + Fh/c.ms;
      e  = max(-1, min(1, a/c.Sa));
      de = max(-1, min(1, xd(2)/c.Sv));
      me = max(0, 1 - abs(e  - c.cen)/0.5);
      md = max(0, 1 - abs(de - c.cen)/0.5);
      W  = me(:) * md(:)';
      u  = c.Su * sum(sum(W .* c.Ctab)) / sum(W(:));
    case 'LQR'
      u = -c.K * xd;
    case 'L1_Adaptive'
      xt = c.xh - xd;                              % prediction error
      sg = c.G * xt;                               % [sigma_m; sigma_um]
      sm = max(-c.bnd, min(c.bnd, sg(1)));         % projection
      sg(1) = sm;
      c.xh = c.Ad*c.xh + c.Phi*(c.b*(Fh + sm) + c.Bum*sg(2:4));
      c.sf = c.al*sm + (1 - c.al)*c.sf;            % low-pass C(s)
      u = -c.K * xd - c.sf;
    otherwise
      error('Unknown controller %s', c.kind);
  end
end

function d = simulate_loop(kind, theta, zr, p, pn, K)
%SIMULATE_LOOP  p = TRUE plant/actuator, pn = NOMINAL model used for design.
%  Returns [] if the loop diverges.
  dt = p.dt;  zr = zr(:);  N = numel(zr);
  [A, b, E] = make_plant(p);  [Ad, Bd, Ed] = c2d_zoh(A, b, E, dt);
  c  = controller_init(kind, theta, pn, K);
  nd = max(1, round(p.tau_d/dt));  al = dt/(p.tau_a + dt);
  X = zeros(N,4);  Fa = zeros(N,1);  Fc = zeros(N,1);
  x = zeros(4,1);  Fr = 0;  Fl = 0;
  for k = 1:N
    X(k,:) = x';
    xd = X(max(k-nd, 1), :)';
    if k - nd >= 1, Fh = Fa(k-nd); else, Fh = 0; end
    [u, c] = controller_step(c, xd, Fh);
    Fc(k) = u;
    us = max(-p.F_max, min(p.F_max, u));                           % saturation
    Fr = Fr + max(-p.dF_max*dt, min(p.dF_max*dt, us - Fr));        % rate limit
    Fl = Fl + al*(Fr - Fl);                                        % actuator lag
    Fa(k) = Fl;
    x = Ad*x + Bd*Fl + Ed*zr(k);
    if ~all(isfinite(x)) || max(abs(x)) > 5, d = [];  return; end
  end
  zs = X(:,1);  zsd = X(:,2);  zu = X(:,3);  zud = X(:,4);
  d.zs = zs;  d.zsd = zsd;  d.zu = zu;  d.zud = zud;  d.zr = zr;
  d.force = Fa;  d.force_cmd = Fc;
  d.acc  = (-p.ks*(zs - zu) - p.cs*(zsd - zud) + Fa) / p.ms;
  d.susp = zs - zu;
  d.tire = zu - zr;                        % tire deflection ALWAYS zu - zr
end

function res = eval_all_controllers(order, theta, zr, p_true, pn, K)
  res = cell(1, numel(order));
  for c = 1:numel(order)
    d = simulate_loop(order{c}, theta.(order{c}), zr, p_true, pn, K);
    res{c} = quick_metrics(d, p_true);
  end
end

% -------------------------------------------------------------- tuning ---
function J = tuning_cost(kind, th, scen, base, pn, K)
  J = 0;
  for i = 1:numel(scen)
    d = simulate_loop(kind, th, scen(i).zr, scen(i).p, pn, K);
    if isempty(d), J = 1e3;  return; end
    q = quick_metrics(d, scen(i).p);
    if ~all(isfinite([q.aw q.tire q.susp q.rmsF])), J = 1e3;  return; end
    J = J + q.aw/base{i}.aw + 0.5*q.tire/base{i}.tire + 0.3*q.susp/base{i}.susp ...
          + 0.2*q.rmsF/pn.F_max + 10*max(0, q.maxs/0.08 - 1);   % 80 mm rattle space
  end
  J = J / numel(scen);
end

function [th, J] = tune_controller(kind, th0, scen, base, pn, K, maxfev)
  f    = @(t) tuning_cost(kind, t(:)', scen, base, pn, K);
  opts = optimset('MaxFunEvals', maxfev, 'MaxIter', maxfev, 'TolX', 1e-2, 'TolFun', 1e-3, 'Display', 'off');
  J0 = f(th0);
  [th, J] = fminsearch(f, th0, opts);
  if J > J0, th = th0;  J = J0; end
  fprintf('  tuned %-12s J: %.4f -> %.4f   theta = %s\n', kind, J0, J, mat2str(th, 4));
end

function f = l1_multiobj(g, zr, p, K)
  d = simulate_loop('L1_Adaptive', g(:)', zr, p, p, K);
  if isempty(d), f = [1e3 1e3 1e3];  return; end
  f = [iso_weighted(d.acc, p.dt), rms_(d.force), sum(max(0, d.force.*(d.zsd - d.zud)))*p.dt];
end

function [g, names] = l1_gain_report(p, wc)
%L1_GAIN_REPORT  L1 norm of G(s) = (sI-A)^-1 b (1 - C(s)), C = wc/(s+wc), per state.
%  The L1 stability condition requires ||G||_L1 * L < 1-type bounds with L the
%  Lipschitz constant of the uncertainty (Cao & Hovakimyan 2008); report these
%  numbers and bound L in the paper rather than claiming stability by simulation.
  [A, b, ~] = make_plant(p);
  Hs = ss(A, b, eye(4), zeros(4,1));
  Fs = ss(-wc, 1, -wc, 1);                         % 1 - C(s) = s/(s+wc)
  G  = series(Fs, Hs);
  t  = linspace(0, 20, 40001)';
  y  = impulse(G, t);
  g  = trapz(t, abs(y));
  names = {'zs','zs_dot','zu','zu_dot'};
end

function nd = nondominated(F)
  n = size(F,1);  nd = true(n,1);
  for i = 1:n
    for j = 1:n
      if i ~= j && all(F(j,:) <= F(i,:)) && any(F(j,:) < F(i,:))
        nd(i) = false;  break;
      end
    end
  end
end

% ------------------------------------------------------------- metrics ---
function r = rms_(x)
  x = x(:);  r = sqrt(mean(x.^2));
end

function q = quick_metrics(d, p)
  if isempty(d)
    q = struct('aw',NaN,'tire',NaN,'susp',NaN,'maxs',NaN,'rmsF',NaN,'stable',0);  return;
  end
  q = struct('aw', iso_weighted(d.acc, p.dt), 'tire', rms_(d.tire), 'susp', rms_(d.susp), ...
             'maxs', max(abs(d.susp)), 'rmsF', rms_(d.force), 'stable', 1);
end

function m = nan_metrics()
  m = struct('Stable',0,'Window_s',NaN,'RMS_acc',NaN,'ISO_aw',NaN,'VDV',NaN,'MTVV',NaN, ...
    'Band1_0p5_4Hz',NaN,'Band2_4_8Hz',NaN,'Band3_8_20Hz',NaN, ...
    'RMS_susp',NaN,'Max_susp',NaN,'RMS_tire',NaN,'RMS_dynload_ratio',NaN, ...
    'RMS_force',NaN,'Peak_force',NaN,'Peak_acc',NaN,'W_pos_J',NaN,'Sat_pct',NaN);
end

function m = compute_metrics(d, p, mask)
%COMPUTE_METRICS  all metrics on the samples selected by mask (no zero-filling).
  m = nan_metrics();
  if isempty(d) || sum(mask) < 100, return; end
  mask = mask(:);  dt = p.dt;
  a = d.acc(mask);
  m.Stable = 1;  m.Window_s = numel(a)*dt;
  m.RMS_acc = rms_(a);
  [m.ISO_aw, m.VDV, m.MTVV] = iso_weighted(a, dt);
  bnd = band_rms(a, dt, [0.5 4; 4 8; 8 20]);
  m.Band1_0p5_4Hz = bnd(1);  m.Band2_4_8Hz = bnd(2);  m.Band3_8_20Hz = bnd(3);
  m.RMS_susp = rms_(d.susp(mask));  m.Max_susp = max(abs(d.susp(mask)));
  m.RMS_tire = rms_(d.tire(mask));
  m.RMS_dynload_ratio = p.kt*m.RMS_tire / ((p.ms + p.mu)*p.g);      % dynamic / static tire load
  F = d.force(mask);
  m.RMS_force = rms_(F);  m.Peak_force = max(abs(F));  m.Peak_acc = max(abs(a));
  m.W_pos_J = sum(max(0, F .* (d.zsd(mask) - d.zud(mask)))) * dt;   % positive actuator work
  if isfield(d, 'force_cmd') && ~isempty(d.force_cmd)
    m.Sat_pct = 100*mean(abs(d.force_cmd(mask)) >= p.F_max);
  end
end

function H = iso_wk_response(f)
%ISO_WK_RESPONSE  ISO 2631-1:1997 Wk (vertical, seat) weighting, complex response.
%  Band limiting (0.4 Hz HP, 100 Hz LP, 2nd-order Butterworth), a-v transition
%  and upward step.  Verified against the standard's Wk table (error < 0.2 %).
  s = 1i*2*pi*f(:);  w = @(x) 2*pi*x;
  f1 = 0.4;  f2 = 100;  f3 = 12.5;  f4 = 12.5;  Q4 = 0.63;
  f5 = 2.37; Q5 = 0.91; f6 = 3.35;  Q6 = 0.91;
  Hh = s.^2 ./ (s.^2 + sqrt(2)*w(f1)*s + w(f1)^2);
  Hl = w(f2)^2 ./ (s.^2 + sqrt(2)*w(f2)*s + w(f2)^2);
  Ht = (1 + s/w(f3)) ./ (1 + s/(Q4*w(f4)) + s.^2/w(f4)^2);
  Hs = (s.^2 + w(f5)/Q5*s + w(f5)^2) ./ (s.^2 + w(f6)/Q6*s + w(f6)^2);
  H = Hh .* Hl .* Ht .* Hs;
end

function [aw, vdv, mtvv] = iso_weighted(a, dt)
%ISO_WEIGHTED  frequency-domain Wk weighting (zero-padded, no filtfilt).
%  aw = weighted RMS, vdv = vibration dose value (m/s^1.75), mtvv = max
%  transient vibration value (1 s running RMS).
  a = a(:);  a(~isfinite(a)) = 0;  n = numel(a);
  nf = 2^nextpow2(2*n);  half = nf/2;
  X  = fft(a, nf);
  Hh = iso_wk_response((0:half)'/(nf*dt));
  H  = zeros(nf,1);  H(1:half+1) = Hh;  H(half+2:end) = conj(Hh(half:-1:2));
  y  = real(ifft(X .* H));  y = y(1:n);
  aw  = sqrt(mean(y.^2));
  vdv = (sum(y.^4)*dt)^0.25;
  w   = min(n, max(1, round(1/dt)));
  mtvv = sqrt(max(movmean(y.^2, w)));
end

function b = band_rms(a, dt, edges)
%BAND_RMS  band RMS by Parseval on the FFT (bands partition the energy).
  a = a(:);  n = numel(a);  X = fft(a);  f = (0:n-1)'/(n*dt);
  Pw = abs(X).^2 / n^2;
  b = zeros(size(edges,1), 1);
  for i = 1:size(edges,1)
    mk = f >= edges(i,1) & f < edges(i,2) & f < 1/(2*dt);
    b(i) = sqrt(2*sum(Pw(mk)));
  end
end

% --------------------------------------------------------------- roads ---
function r = iso_road_profile(cls, seed, T, p)
%ISO_ROAD_PROFILE  ISO 8608 random road (class A-D) by spectral synthesis.
  switch upper(cls)
    case 'A', Gd0 = 16e-6;   case 'B', Gd0 = 64e-6;
    case 'C', Gd0 = 256e-6;  case 'D', Gd0 = 1024e-6;
    otherwise, error('Unknown ISO class');
  end
  dt = p.dt;  N = round(T/dt) + 1;  df = 1/(N*dt);
  k = (1:floor(N/2)-1)';  fk = k*df;  nk = fk/p.v;
  Sd = Gd0 * (nk/0.1).^(-2);  Sf = Sd/p.v;  Sf(nk < 0.011) = 0;
  amp = sqrt(2*Sf*df);
  s = RandStream('mt19937ar', 'Seed', seed);
  ph = 2*pi*rand(s, numel(k), 1);
  Z = zeros(N,1);  Z(k+1) = amp .* exp(1i*ph);
  r = struct('t', (0:N-1)'*dt, 'zr', imag(N*ifft(Z)));
end

function r = synthetic_road(name, T, dt)
  t = (0:dt:T)';
  switch lower(name)
    case 'step',   zr = 0.020*(t >= 1);
    case 'stairs'
      zr = zeros(size(t));
      zr(t>=1 & t<3) = 0.010;   zr(t>=3 & t<5)  = 0.020;  zr(t>=5 & t<7)  = -0.012;
      zr(t>=7 & t<9) = 0.015;   zr(t>=9 & t<11) = -0.018; zr(t>=11)       = 0.020;
    case 'variablefreq'
      zr = 0.010*sin(2*pi*(0.5*t + (8-0.5)*t.^2/(2*10)));
    case 'sinewave', zr = 0.010*sin(2*pi*1.5*t);
    case 'bump'
      zr = zeros(size(t));  m = (t >= 1) & (t < 1.18);
      zr(m) = 0.050*sin(pi*(t(m)-1)/0.18);
    otherwise, error('Unknown road %s', name);
  end
  r = struct('t', t, 'zr', zr);
end

function r = resample_road(t, zr, dt)
%RESAMPLE_ROAD  sort, de-duplicate, close NaN holes, put on a uniform grid.
  t = t(:);  zr = zr(:);  ok = isfinite(t);  t = t(ok);  zr = zr(ok);
  [t, iu] = unique(t);  zr = zr(iu);
  if any(isnan(zr)) && any(~isnan(zr))
    zr = fillmissing(zr, 'linear', 'EndValues', 'nearest');
  end
  zr(isnan(zr)) = 0;
  tu = (t(1):dt:t(end))';
  r = struct('t', tu, 'zr', interp1(t, zr, tu, 'linear'));
end

% ------------------------------------------------------------- figures ---
function panel_bars(summary, roads, ctrls, colors, field, ylab)
  nC = numel(ctrls);  labels = strrep(ctrls, '_', ' ');
  for r = 1:numel(roads)
    subplot(2, 3, r);  vals = zeros(nC, 1);
    for c = 1:nC
      i = find(strcmp(summary.Road, roads{r}) & strcmp(summary.Controller, ctrls{c}));
      vals(c) = summary.(field)(i);
    end
    b = bar(vals, 'FaceColor', 'flat', 'EdgeColor', 'none');  grid on;
    b.CData = colors(1:nC, :);
    set(gca, 'XTick', 1:nC, 'XTickLabel', labels, 'XTickLabelRotation', 35);
    title(roads{r}, 'FontSize', 8);  ylabel(ylab);
  end
end

function save_journal_figure(fig, name)
%SAVE_JOURNAL_FIGURE  600-dpi PNG + vector PDF (Vehicle System Dynamics artwork).
  print(fig, name, '-dpng', '-r600');
  try
    exportgraphics(fig, [name '.pdf'], 'ContentType', 'vector');
  catch
    print(fig, name, '-dpdf');
  end
  fprintf('  saved %s.png / %s.pdf\n', name, name);
end

% ------------------------------------------------------- legacy loader ---
function w = sanitize_cell(v)
%SANITIZE_CELL  numeric -> double; text -> trimmed, BOM/control chars removed; else ''.
  if isnumeric(v) || islogical(v), w = double(v);  return; end
  if ischar(v), w = strtrim(v);
  elseif isstring(v)
    if ismissing(v), w = ''; else, w = strtrim(char(v)); end
  else, w = '';
  end
  if ~isempty(w), dcode = double(w);  w = w(dcode >= 32 & dcode ~= 65279); end
end

function M = cell_to_numeric(C)
  M = NaN(size(C));
  for i = 1:numel(C)
    v = C{i};
    if isnumeric(v) && isscalar(v), M(i) = double(v);
    elseif ischar(v) && ~isempty(v), M(i) = str2double(v);
    end
  end
end

function rd = canon_road(raw)
  rl = lower(strtrim(raw));
  if startsWith(rl, 'step'),        rd = 'Step';
  elseif startsWith(rl, 'stairs'),  rd = 'Stairs';
  elseif startsWith(rl, 'variable'), rd = 'VariableFreq';
  elseif startsWith(rl, 'sine'),    rd = 'SineWave';
  elseif startsWith(rl, 'bump'),    rd = 'Bump';
  else, rd = matlab.lang.makeValidName(raw);
  end
end

function nm = canon_ctrl(raw)
  rl = lower(strtrim(raw));
  switch rl
    case {'passive','pssive'}, nm = 'Passive';
    case 'pid',   nm = 'PID';
    case 'fuzzy', nm = 'Fuzzy';
    case 'fpid',  nm = 'FPID';
    case 'road',  nm = 'Road';
    otherwise,    nm = matlab.lang.makeValidName(raw);
  end
end

function B = read_blocks(fname)
%READ_BLOCKS  parse the 2-header-row layout: row1 = road (blank = same as left),
%  row2 = signal names, first 'Time' column of each block = its own time axis.
%  Returns B.(road).(signal) = struct('t', t, 'y', y) with NaNs preserved.
  C = readcell(fname);
  C = cellfun(@sanitize_cell, C, 'UniformOutput', false);
  nc = size(C, 2);  road_f = cell(1, nc);  last = '';
  for i = 1:nc
    v = C{1,i};
    if ischar(v) && ~isempty(v), last = v; end
    road_f{i} = last;
  end
  roads_raw = unique(road_f(~cellfun(@isempty, road_f)), 'stable');
  B = struct();
  for ri = 1:numel(roads_raw)
    raw = roads_raw{ri};  rd = canon_road(raw);
    cols = find(strcmp(road_f, raw));  tcol = [];
    for ci = cols
      nm = C{2,ci};
      if ischar(nm) && strcmpi(nm, 'time'), tcol = ci;  break; end
    end
    if isempty(tcol), continue; end
    t = cell_to_numeric(C(3:end, tcol));
    for ci = cols
      nm = C{2,ci};
      if ~ischar(nm) || isempty(nm) || ci == tcol, continue; end
      B.(rd).(canon_ctrl(nm)) = struct('t', t, 'y', cell_to_numeric(C(3:end, ci)));
    end
  end
end

function v = grab(Bsig, rd, cn, t)
%GRAB  signal interpolated on time grid t; NaN outside its range or inside gaps > 5 ms.
  v = NaN(size(t));
  if ~isfield(Bsig, rd) || ~isfield(Bsig.(rd), cn), return; end
  blk = Bsig.(rd).(cn);
  ok = isfinite(blk.t) & isfinite(blk.y);
  [tu, iu] = unique(blk.t(ok));  yv = blk.y(ok);  yv = yv(iu);
  if numel(tu) < 2, return; end
  v = interp1(tu, yv, t, 'linear', NaN);
  near = interp1(tu, tu, t, 'nearest', 'extrap');
  v(abs(t - near) > 0.005) = NaN;
end

function L = load_legacy(F)
  sigs = {'acceleration','body_position','body_velocity','force','tire_position','vert_error'};
  B = struct();
  for i = 1:numel(sigs)
    fprintf('  reading %s ...\n', F.(sigs{i}));
    B.(sigs{i}) = read_blocks(F.(sigs{i}));
  end
  ctrls = {'Passive','PID','Fuzzy','FPID'};
  roads = fieldnames(B.acceleration);
  L.data = struct();  L.road_inputs = struct();
  for r = 1:numel(roads)
    rd = roads{r};  rr = [];
    if isfield(B.body_position, rd) && isfield(B.body_position.(rd), 'Road')
      rb = B.body_position.(rd).Road;
      rr = resample_road(rb.t, rb.y, 1e-3);
      L.road_inputs.(rd) = struct('t', rb.t, 'zr', rb.y);
    end
    for c = 1:numel(ctrls)
      cn = ctrls{c};
      if ~isfield(B.acceleration.(rd), cn), continue; end
      a = B.acceleration.(rd).(cn);  t = a.t(:);
      s = struct('t', t, 'acc', a.y(:));
      s.zs  = grab(B.body_position, rd, cn, t);
      s.zsd = grab(B.body_velocity, rd, cn, t);
      s.zu  = grab(B.tire_position, rd, cn, t);
      s.vert_err = grab(B.vert_error, rd, cn, t);
      if strcmp(cn, 'Passive'), s.force = zeros(size(t));
      else, s.force = grab(B.force, rd, cn, t); end
      if ~isempty(rr), s.zr = interp1(rr.t, rr.zr, t, 'linear', NaN);
      else, s.zr = NaN(size(t)); end
      L.data.(rd).(cn) = s;
    end
  end
  fprintf('  legacy roads: %s\n', strjoin(fieldnames(L.data)', ', '));
end

function [audit, leg] = legacy_audit(L, p)
%LEGACY_AUDIT  (1) rebuild acceleration from logged zs, zu, zs_dot, force through
%  the quarter-car equation  ms*a = -ks(zs-zu) - cs(zs_dot-zu_dot) + F  and compare
%  with the logged acceleration; (2) compare the logged force with the force
%  implied by the acceleration reduction relative to Passive (ms*rms(a_P - a_C)).
%  (3) recompute all metrics with the FIXED pipeline on the valid window only.
  rows = {};  mrows = {};
  roads = fieldnames(L.data);
  for r = 1:numel(roads)
    rd = roads{r};  cn_all = fieldnames(L.data.(rd))';
    for cn = cn_all
      cn = cn{1};  d = L.data.(rd).(cn);  t = d.t(:);
      zud = gradient(d.zu, t);
      acc_re = (-p.ks*(d.zs - d.zu) - p.cs*(d.zsd - zud) + d.force) / p.ms;
      valid = isfinite(d.acc) & isfinite(acc_re) & isfinite(d.zs) & isfinite(d.zu) ...
              & isfinite(d.zsd) & isfinite(d.force);
      cov = 100*sum(valid)/numel(t);
      cc = NaN;  nr = NaN;  rf = NaN;  fl = NaN;  fi = NaN;  ratio = NaN;
      if sum(valid) > 100
        x = d.acc(valid);  y = acc_re(valid);
        cm = corrcoef(x, y);  cc = cm(1,2);
        nr = rms_(x - y)/rms_(x);  rf = p.ms*rms_(x - y);
        fl = rms_(d.force(valid));
        if isfield(L.data.(rd), 'Passive') && ~strcmp(cn, 'Passive')
          P = L.data.(rd).Passive;  okp = isfinite(P.acc) & isfinite(P.t);
          [tp, ip] = unique(P.t(okp));  ap = P.acc(okp);  ap = ap(ip);
          aP = interp1(tp, ap, t, 'linear', NaN);
          v2 = valid & isfinite(aP);
          if sum(v2) > 100
            fi = p.ms*rms_(aP(v2) - d.acc(v2));  ratio = fl/fi;
          end
        end
      end
      flag = 'OK';
      if ~isfinite(cc) || cc < 0.9 || nr > 0.25, flag = 'INCONSISTENT';
      elseif isfinite(ratio) && ratio < 0.3,      flag = 'FORCE_WARNING'; end
      rows{end+1,1} = struct('Road', rd, 'Controller', cn, 'Samples', numel(t), ...
        'Coverage_pct', cov, 'Corr_acc', cc, 'NRMSE_acc', nr, 'Resid_force_N', rf, ...
        'Force_logged_N', fl, 'Force_implied_N', fi, 'Force_ratio', ratio, 'Flag', flag);  %#ok<AGROW>
      dd = struct('acc', d.acc, 'susp', d.zs - d.zu, 'tire', d.zu - d.zr, 'force', d.force, ...
                  'zsd', d.zsd, 'zud', zud, 'force_cmd', []);
      mask = valid & isfinite(d.zr);
      m = compute_metrics(dd, p, mask);
      m.Road = rd;  m.Controller = cn;  m.Source = 'Legacy_Simulink_fixed_metrics';
      m.Coverage_pct = 100*sum(mask)/numel(t);
      mrows{end+1,1} = m;  %#ok<AGROW>
    end
  end
  audit = struct2table(vertcat(rows{:}));
  leg   = struct2table(vertcat(mrows{:}));
  leg   = movevars(leg, {'Road','Controller','Source'}, 'Before', 1);
end
