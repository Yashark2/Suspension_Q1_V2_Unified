"""Per-seed force-matched gaps on 10 test realisations (ISO class C, seeds 21-30) with CIs.
Frontier A: 360-design LQR family + gain-scaled tuned LQR on independent seeds 31-33.
Frontier B (optional, if rev_front2_iso.pkl exists): same on independent seeds 34-36."""
import numpy as np, pickle, json, os, inspect, sys
import mirror
from mirror import *
from scipy import stats
TH=dict(PID=[2.32,2.747,-2.99],Fuzzy=[-0.1535,-0.4699,2.621],FPID=[2.446,2.45,-2.393,2.261,0.26],LQR=[4.503,4.446])
mirror.LQRK=lqr_out(P,10**4.503,10**4.446)
src=inspect.getsource(simulate).replace("rec=True):","rec=True,g=1.0):").replace("def simulate(","def sim2(").replace("x=Ad@x+Bd*Fl+Ed*zr[k]","x=Ad@x+Bd*g*Fl+Ed*zr[k]").replace("Fa[k]=Fl;","Fa[k]=g*Fl;")
exec(src,globals())
G=[0.2,0.3,0.4,0.5,0.6,0.7,0.85,1.0,1.2,1.5]
def envelope(pts):
    P_=np.array(pts);P_=P_[np.argsort(P_[:,1])];F=[0.];R=[0.];best=0.
    for r,f in P_:
        if r>best:best=r;F.append(f);R.append(r)
    return np.array(F),np.array(R)
def scaled_rows(seeds):
    zs=[iso_road('C',s,10.)[1] for s in seeds];aP=[met(simulate('Passive',[0],z,P,P),P)['aw'] for z in zs];rows=[]
    for g in G:
        R=[];F=[]
        for z,a in zip(zs,aP):
            d=sim2('LQR',TH['LQR'],z,P,P,g=g)
            if d is None:break
            m=met(d,P);R.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
        else:rows.append((float(np.mean(R)),float(np.mean(F))))
    return rows
def frontier(pkl,key,rows):
    d=pickle.load(open(pkl,'rb'))[key];pts=[(p[3],p[4]) for p in d]+rows;return envelope(pts)
fa_rows=[(r[1],r[2]) for r in json.load(open('rev_scale.json'))['ISO_C_31_33']['LQR']]
fr={'A':frontier('rev_front_iso.pkl','ISO_C_indep',fa_rows)}
if os.path.exists('rev_front2_iso.pkl') and len(sys.argv)>1:
    fr['B']=frontier('rev_front2_iso.pkl','ISO_C_B',scaled_rows((34,35,36)))
SEEDS=list(range(21,31));zs=[iso_road('C',s,10.)[1] for s in SEEDS]
aP=[met(simulate('Passive',[0],z,P,P),P)['aw'] for z in zs]
res={}
for k in ['PID','Fuzzy','FPID','LQR']:
    R=[];F=[]
    for z,a in zip(zs,aP):
        m=met(simulate(k,TH[k],z,P,P),P);R.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
    R=np.array(R);F=np.array(F);res[k]=dict(R=R.tolist(),F=F.tolist())
    for fn,(Fe,Re) in fr.items():
        gap=R-np.interp(F,Fe,Re);n=len(gap);se=gap.std(ddof=1)/np.sqrt(n);t=stats.t.ppf(.975,n-1)
        try:p=float(stats.wilcoxon(gap).pvalue)
        except Exception:p=float('nan')
        res[k]['gap_'+fn]=dict(mean=float(gap.mean()),sd=float(gap.std(ddof=1)),lo=float(gap.mean()-t*se),hi=float(gap.mean()+t*se),p=p,npos=int((gap>0).sum()),gaps=gap.tolist())
    print(k,round(R.mean(),2),round(F.mean(),1),{fn:(round(res[k]['gap_'+fn]['mean'],2),round(res[k]['gap_'+fn]['lo'],2),round(res[k]['gap_'+fn]['hi'],2),res[k]['gap_'+fn]['npos']) for fn in fr},flush=True)
res['frontiers']={fn:[F_.tolist(),R_.tolist()] for fn,(F_,R_) in fr.items()}
json.dump(res,open('rev_ci%s.json'%('_B' if 'B' in fr else '_A'),'w'),indent=1)
