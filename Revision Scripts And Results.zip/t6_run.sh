#!/bin/sh
cd /workspace/chat-d4e479da
(python3 rev_tune6.py Fuzzy 120 > t6_Fuzzy.log 2>&1; python3 rev_tune6.py PID 120 > t6_PID.log 2>&1; python3 rev_tune6.py FPID 120 > t6_FPID.log 2>&1) &
(python3 rev_tune6.py LQR 120 > t6_LQR.log 2>&1; python3 rev_tune6.py L1 100 > t6_L1.log 2>&1) &
wait
