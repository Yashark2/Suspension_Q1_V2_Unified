import pickle,json,numpy as np
def near_designs():
    d=pickle.load(open('rev_front_iso.pkl','rb'))['ISO_C_indep']
    rows=[(r[1],r[2]) for r in json.load(open('rev_scale.json'))['ISO_C_31_33']['LQR']]
    pts=np.array([(p[3],p[4]) for p in d]+rows);o=np.argsort(pts[:,1]);F=[0.];R=[0.];b=0.
    for r,f in pts[o]:
        if r>b:b=r;F.append(f);R.append(r)
    return [(p[0],p[1],p[2]) for p in d if p[3]>=np.interp(p[4],F,R)-1.5]
