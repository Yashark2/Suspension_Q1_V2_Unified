import numpy as np, pickle, itertools, time, sys
import mirror
from mirror import *
import pandas as pd
which=sys.argv[1]
D=pickle.load(open('raw.pkl','rb'))['zs']
def road(name):
    r=D.iloc[0].ffill().astype(str).str.lower();cols=[i for i in range(D.shape[1]) if r[i].startswith(name)]
    names=[str(x).lower() for x in D.iloc[1,cols]];b=D.iloc[2:,cols].apply(pd.to_numeric,errors='coerce');b.columns=names
    t=b['time'].values;z=b['road'].values;ok=np.isfinite(t)&np.isfinite(z);t,z=t[ok],z[ok];_,iu=np.unique(t,return_index=True);t,z=t[iu],z[iu]
    tu=np.arange(t[0],t[-1],1e-3);return np.interp(tu,t,z)
orig=mirror.lqr_out;RS0,RT0=10**4.503,10**4.446
GRID=list(itertools.product([3,1,.3,.1,.03,.01],[3,1,.3,.1,.03,.01],[1e-5,5.6e-6,3e-6,1.8e-6,1e-6,5.6e-7,3e-7,1.8e-7,1e-7,3e-8]))
if which=='iso':
    roads={'ISO_C_indep':[iso_road('C',s,10.)[1] for s in (31,32,33)],'ISO_C_test':[iso_road('C',s,10.)[1] for s in (21,22,23)]}
else:
    roads={'VariableFreq':[road('variable')],'Bump':[road('bump')]}
out={};t0=time.time()
for nm,zs in roads.items():
    aP=[met(simulate('Passive',[0],z,P,P),P)['aw'] for z in zs];pts=[]
    for a,b,rf in GRID:
        mirror.lqr_out=lambda P_,rs,rt,a=a,b=b,rf=rf:orig(P_,RS0*a,RT0*b,rF=rf)
        try: ms=[simulate('LQR',[0,0],z,P,P) for z in zs]
        except Exception: continue
        if any(m is None for m in ms):continue
        ms=[met(m,P) for m in ms]
        pts.append((a,b,rf,np.mean([100*(p-m['aw'])/p for p,m in zip(aP,ms)]),np.mean([m['rmsF'] for m in ms]),np.mean([m['susp'] for m in ms]),np.mean([m['tire'] for m in ms])))
    mirror.lqr_out=orig;out[nm]=pts;print(nm,len(pts),round(time.time()-t0),flush=True)
    pickle.dump(out,open('rev_front_%s.pkl'%which,'wb'))
