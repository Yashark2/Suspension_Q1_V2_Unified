# exact state-reconstructed implied force for the legacy logs (needs raw.pkl produced by audit_py.py)
import pickle,numpy as np,pandas as pd
ms,ks,cs=400,20800,4800
D=pickle.load(open('raw.pkl','rb'))
def blk(d,road):
    r=d.iloc[0].ffill().astype(str).str.lower();cols=[i for i in range(d.shape[1]) if r[i].startswith(road)]
    names=[('passive' if str(x).lower().startswith('ps') else str(x).lower()) for x in d.iloc[1,cols]]
    b=d.iloc[2:,cols].apply(pd.to_numeric,errors='coerce');b.columns=names;return b
for road in ['step','stairs','variable','sine','bump']:
    B={k:blk(D[k],road) for k in D}
    for c in ['pid','fuzzy','fpid']:
        t=B['acc']['time'].values;acc,zs,zsd,zu,F=[B[k][c].values for k in ('acc','zs','zsd','zu','F')]
        n=min(map(len,[acc,zs,zsd,zu,F,t]));acc,zs,zsd,zu,F,tt=[x[:n] for x in (acc,zs,zsd,zu,F,t)]
        zud=np.gradient(zu,tt);Fi=ms*acc+ks*(zs-zu)+cs*(zsd-zud);v=np.isfinite(Fi)&np.isfinite(F)
        print(road,c,round(100*np.sqrt(np.mean(F[v]**2))/np.sqrt(np.mean(Fi[v]**2)),2))
