#!/bin/sh
cd /workspace/chat-d4e479da
(python3 rev_tune6m.py PID 120 > t6m_PID.log 2>&1; python3 rev_tune6m.py Fuzzy 120 > t6m_Fuzzy.log 2>&1; python3 rev_tune6m.py FPID 120 > t6m_FPID.log 2>&1) &
(python3 rev_tune6m.py LQR 120 > t6m_LQR.log 2>&1; python3 rev_tune6m.py L1 100 > t6m_L1.log 2>&1) &
wait
