import numpy as np, json, mirror
from mirror import *
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000);P2d=dict(P2);P2d['tau_d']=0.02
z=iso_road('C',21,10.)[1];a=met(simulate('Passive',[0],z,P2d,P2),P2d)['aw']
res=[]
for t0 in [0,1,2,3,4,5,6]:
    for t1 in [2,3,4,5,6,7]:
        d=simulate('LQR',[t0,t1],z,P2d,P2)
        if d is None: continue
        m=met(d,P2d);res.append((t0,t1,100*(a-m['aw'])/a,m['rmsF']))
res.sort(key=lambda r:-r[2]);print('LQR best grid:',[tuple(round(v,2) for v in r) for r in res[:5]])
res=[]
for s in [-1,-0.5,0,0.5]:
    for u in [2.0,2.5,3.0,3.17]:
        for w in [-1.5,-1,-0.5,0]:
            d=simulate('Fuzzy',[s,w,u],z,P2d,P2)
            if d is None: continue
            m=met(d,P2d);res.append((s,w,u,100*(a-m['aw'])/a,m['rmsF']))
res.sort(key=lambda r:-r[3]);print('Fuzzy best grid:',[tuple(round(v,2) for v in r) for r in res[:5]])
