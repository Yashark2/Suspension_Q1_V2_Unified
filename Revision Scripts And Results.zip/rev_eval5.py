"""Evaluation of the larger-budget re-tuning. usage: rev_eval5.py delay|plant2"""
import sys, json, pickle, inspect, numpy as np, mirror
from mirror import *
from scipy import stats
part=sys.argv[1]
TH=dict(PID=[2.32,2.747,-2.99],Fuzzy=[-0.1535,-0.4699,2.621],FPID=[2.446,2.45,-2.393,2.261,0.26],LQR=[4.503,4.446],L1=[1.877,-3.0])
src=inspect.getsource(simulate).replace("rec=True):","rec=True,g=1.0):").replace("def simulate(","def sim2(").replace("x=Ad@x+Bd*Fl+Ed*zr[k]","x=Ad@x+Bd*g*Fl+Ed*zr[k]").replace("Fa[k]=Fl;","Fa[k]=g*Fl;")
exec(src,globals())
G=[0.2,0.3,0.4,0.5,0.6,0.7,0.85,1.0,1.2,1.5,2.0,2.6]
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000)
def envelope(pts):
    P_=np.array(pts);P_=P_[np.argsort(P_[:,1])];F=[0.];R=[0.];b=0.
    for r,f in P_:
        if r>b:b=r;F.append(f);R.append(r)
    return np.array(F),np.array(R)
def gapstats(R,F,fam):
    g=[]
    for s in range(len(R)):
        Fe,Re=envelope([(r[0][s],r[1][s]) for r in fam]);g.append(R[s]-np.interp(F[s],Fe,Re))
    g=np.array(g);n=len(g);se=g.std(ddof=1)/np.sqrt(n);t=stats.t.ppf(.975,n-1)
    try:p=float(stats.wilcoxon(g).pvalue)
    except Exception:p=float('nan')
    return dict(mean=float(g.mean()),lo=float(g.mean()-t*se),hi=float(g.mean()+t*se),p=p,npos=int((g>0).sum()),n=n)
def runs(kind,th,zs,Pp,Pd,aP,g=1.0):
    R=[];F=[];T=[];S=[]
    for z,a in zip(zs,aP):
        d=sim2(kind,th,z,Pp,Pd,g=g);m=met(d,Pp);R.append(100*(a['aw']-m['aw'])/a['aw']);F.append(m['rmsF']);T.append(m['tire']/a['tire']);S.append(m['susp']/a['susp'])
    return R,F,T,S
def family(zs,Pp,Pd,aP,lq,designs):
    fam=[];orig=mirror.lqr_out
    for a,b,rf in designs:
        mirror.lqr_out=lambda P_,rs,rt,a=a,b=b,rf=rf:orig(P_,10**lq[0]*a,10**lq[1]*b,rF=rf)
        R,F,_,_=runs('LQR',[0,0],zs,Pp,Pd,aP);fam.append((R,F))
    mirror.lqr_out=orig
    for g in G:
        R,F,_,_=runs('LQR',lq,zs,Pp,Pd,aP,g=g);fam.append((R,F))
    return fam
out={}
if part=='delay':
    P20=dict(P);P20['tau_d']=0.02;zs=[iso_road('C',s,10.)[1] for s in range(24,34)]
    aP=[met(simulate('Passive',[0],z,P20,P),P20) for z in zs];aP5=[met(simulate('Passive',[0],z,P,P),P) for z in zs]
    J={k:json.load(open('rev_t5_delay_%s.json'%k)) for k in ['PID','Fuzzy','FPID','LQR','L1']}
    lq=J['LQR']['theta'];mirror.LQRK=lqr_out(P,10**lq[0],10**lq[1])
    for k in ['PID','Fuzzy','FPID','LQR']:
        R5,F5,_,_=runs(k,TH[k],zs,P,P,aP5);R20,F20,T20,S20=runs(k,TH[k],zs,P20,P,aP)
        Rr,Fr,Tr,Sr=runs(k,J[k]['theta'],zs,P20,P,aP)
        out[k]=dict(red5=np.mean(R5),F5=np.mean(F5),red20=np.mean(R20),F20=np.mean(F20),redR=np.mean(Rr),FR=np.mean(Fr),strokeR=np.mean(Sr),tireR=np.mean(Tr),R20=R20,F20l=F20,RR=Rr,FRl=Fr,theta=J[k]['theta'],J=J[k]['J'],starts=J[k]['starts'])
        print(k,{a:round(b,2) for a,b in out[k].items() if isinstance(b,float)},flush=True)
    for nm,th in [('L1_retuned',J['L1']['theta']),('L1_b1.5N',[1.877,-3.0]),('L1_b150N',[1.877,-1.0])]:
        R,F,T,S=runs('L1',th,zs,P20,P,aP);out[nm]=dict(red=np.mean(R),F=np.mean(F),stroke=np.mean(S),theta=th,R=R)
        print(nm,round(np.mean(R),2),round(np.mean(F)),flush=True)
    from rev_ci_helpers import near_designs
    designs=near_designs()
    fam=family(zs,P20,P,aP,TH['LQR'],designs)
    fam.append(tuple(runs('LQR',lq,zs,P20,P,aP)[:2]))
    for k in ['PID','Fuzzy','FPID','LQR']:
        out[k]['gap_retuned']=gapstats(out[k]['RR'],out[k]['FRl'],fam);out[k]['gap_untuned20']=gapstats(out[k]['R20'],out[k]['F20l'],fam)
        print(k,'gap retuned',out[k]['gap_retuned'],'untuned',out[k]['gap_untuned20'],flush=True)
    json.dump(out,open('rev_eval5_delay.json','w'),indent=1,default=float)
if part=='plant2':
    zs=[iso_road('C',s,10.)[1] for s in range(21,31)];aP=[met(simulate('Passive',[0],z,P2,P2),P2) for z in zs]
    J={k:json.load(open('rev_t5_plant2_%s.json'%k)) for k in ['PID','Fuzzy','FPID','LQR']}
    lq=J['LQR']['theta']
    designs=[(a,1.0,rf) for a in (3,1,.3,.1,.03) for rf in (1e-5,3e-6,1e-6,3e-7,1e-7)]
    for k in ['PID','Fuzzy','FPID','LQR']:
        Ru,Fu,_,_=runs(k,TH[k],zs,P2,P2,aP) if k!='LQR' else (None,None,0,0)
        Rr,Fr,Tr,Sr=runs(k,J[k]['theta'],zs,P2,P2,aP)
        out[k]=dict(theta=J[k]['theta'],J=J[k]['J'],starts=J[k]['starts'],redR=np.mean(Rr),FR=np.mean(Fr),strokeR=np.mean(Sr),tireR=np.mean(Tr),RR=Rr,FRl=Fr)
        try:
            Ru,Fu,_,_=runs(k,TH[k],zs,P2,P2,aP);out[k]['red_untuned']=np.mean(Ru);out[k]['F_untuned']=np.mean(Fu)
        except Exception as e:print('untuned fail',k,e)
        print(k,{a:round(b,2) for a,b in out[k].items() if isinstance(b,float)},flush=True)
    fam=family(zs,P2,P2,aP,lq,designs)
    for k in ['PID','Fuzzy','FPID','LQR']:
        out[k]['gap']=gapstats(out[k]['RR'],out[k]['FRl'],fam);print(k,out[k]['gap'],flush=True)
    json.dump(out,open('rev_eval5_plant2.json','w'),indent=1,default=float)
