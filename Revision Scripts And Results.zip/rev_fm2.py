"""Force-matched comparison on the SECOND plant, 20 ms delay, class-C seeds 24-33.
LQR reference family: weight grid + scaling of the command of several LQR designs; same-road frontier per road."""
import json, inspect, numpy as np, mirror
from mirror import *
from scipy import stats
src=inspect.getsource(simulate).replace("rec=True):","rec=True,g=1.0):").replace("def simulate(","def sim2(").replace("u=c.cmd(xd,Fhd);","u=g*c.cmd(xd,Fhd);")
assert "g*c.cmd" in src
exec(src,globals())
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000);P2d=dict(P2);P2d['tau_d']=0.02
zs=[iso_road('C',s,10.)[1] for s in range(24,34)]
aP=[met(simulate('Passive',[0],z,P2d,P2),P2d)['aw'] for z in zs]
def run(kind,th,g=1.0):
    R=[];F=[]
    for z,a in zip(zs,aP):
        d=sim2(kind,th,z,P2d,P2,g=g)
        if d is None:R.append(-100.);F.append(1e4);continue
        m=met(d,P2d);R.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
    return np.array(R),np.array(F)
th=json.load(open('rev_t6m_LQR.json'))['theta']
designs=[(t0,t1,g) for t0,t1 in [(th[0],th[1]),(0,4),(1,5),(2,5),(3,5),(3,6),(4,5),(2,4)] for g in (0.15,0.3,0.5,0.75,1.0,1.5,2.5)]
fam=[]
for t0,t1,g in designs:
    R,F=run('LQR',[t0,t1],g);fam.append((t0,t1,g,R,F));print('LQR',round(t0,2),round(t1,2),g,round(R.mean(),2),round(F.mean()),flush=True)
def env(pts):
    P_=np.array(pts);P_=P_[np.argsort(P_[:,1])];Fe=[0.];Re=[0.];b=0.
    for r,f in P_:
        if r>b:b=r;Fe.append(f);Re.append(r)
    return np.array(Fe),np.array(Re)
def gaps(R,F):
    g=[]
    for s in range(len(R)):
        Fe,Re=env([(f[3][s],f[4][s]) for f in fam]);g.append(R[s]-np.interp(F[s],Fe,Re))
    g=np.array(g);n=len(g);h=stats.t.ppf(.975,n-1)*g.std(ddof=1)/np.sqrt(n)
    try:p=float(stats.wilcoxon(g).pvalue)
    except Exception:p=float('nan')
    return dict(mean=float(g.mean()),lo=float(g.mean()-h),hi=float(g.mean()+h),p=p,n=n)
out=dict(frontier=[(a,b,c,float(R.mean()),float(F.mean())) for a,b,c,R,F in fam])
for k in ['PID','Fuzzy','FPID','LQR','L1']:
    d=json.load(open('rev_t6m_%s.json'%k))
    if k=='L1':
        lq=json.load(open('rev_t6m_LQR.json'))['theta'];mirror.LQRK=lqr_out(P2,10**lq[0],10**lq[1])
    R,F=run(k,d['theta']);out[k]=dict(red=float(R.mean()),F=float(F.mean()),gap=gaps(R,F));print(k,out[k],flush=True)
json.dump(out,open('rev_fm2.json','w'),indent=1)
