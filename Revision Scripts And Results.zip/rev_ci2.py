"""Same-seed frontier on seeds 21-30 from near-frontier designs (within 1.5 pp of independent frontier A) + scaled-gain LQR."""
import numpy as np, pickle, json, inspect
import mirror
from mirror import *
exec(open('rev_ci.py').read().split("fa_rows=")[0].split("from scipy import stats")[1])
fa_rows=[(r[1],r[2]) for r in json.load(open('rev_scale.json'))['ISO_C_31_33']['LQR']]
d=pickle.load(open('rev_front_iso.pkl','rb'))['ISO_C_indep']
Fe,Re=frontier('rev_front_iso.pkl','ISO_C_indep',fa_rows)
sel=[p for p in d if p[3]>=np.interp(p[4],Fe,Re)-1.5]
print('selected',len(sel),'of',len(d),flush=True)
orig=mirror.lqr_out;RS0,RT0=10**4.503,10**4.446
zs=[iso_road('C',s,10.)[1] for s in range(21,31)]
aP=[met(simulate('Passive',[0],z,P,P),P)['aw'] for z in zs]
rows=[]  # per design: per-seed red and F
for a,b,rf,*_ in sel:
    mirror.lqr_out=lambda P_,rs,rt,a=a,b=b,rf=rf:orig(P_,RS0*a,RT0*b,rF=rf)
    try:ms=[simulate('LQR',[0,0],z,P,P) for z in zs]
    except Exception:continue
    if any(m is None for m in ms):continue
    ms=[met(m,P) for m in ms];rows.append(([100*(p-m['aw'])/p for p,m in zip(aP,ms)],[m['rmsF'] for m in ms]))
    if len(rows)%10==0:print(len(rows),flush=True)
mirror.lqr_out=orig
for g in G:
    mirror.LQRK=lqr_out(P,10**4.503,10**4.446);R=[];F=[]
    for z,a in zip(zs,aP):
        dd=sim2('LQR',TH['LQR'],z,P,P,g=g);m=met(dd,P);R.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
    rows.append((R,F))
pickle.dump(rows,open('rev_ci2.pkl','wb'));print('done',len(rows))
