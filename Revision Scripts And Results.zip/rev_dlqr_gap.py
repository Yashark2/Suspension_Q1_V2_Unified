import json, numpy as np, mirror
from mirror import *
from scipy import stats
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000);P2d=dict(P2);P2d['tau_d']=0.02
fam=json.load(open('rev_dlqr_fam_0.json'))+json.load(open('rev_dlqr_fam_1.json'))
fam=[(np.array(f['R']),np.array(f['F'])) for f in fam]
TE=[iso_road('C',s,10.)[1] for s in range(24,34)];A0=[met(simulate('Passive',[0],z,P2d,P2),P2d)['aw'] for z in TE]
def env(pts):
    P_=np.array(pts);P_=P_[np.argsort(P_[:,1])];Fe=[0.];Re=[0.];b=0.
    for r,f in P_:
        if r>b:b=r;Fe.append(f);Re.append(r)
    return np.array(Fe),np.array(Re)
def gaps(R,F):
    g=[]
    for s in range(10):
        Fe,Re=env([(f[0][s],f[1][s]) for f in fam]);g.append(R[s]-np.interp(F[s],Fe,Re))
    g=np.array(g);h=stats.t.ppf(.975,9)*g.std(ddof=1)/np.sqrt(10)
    try:p=float(stats.wilcoxon(g).pvalue)
    except Exception:p=float('nan')
    return dict(mean=float(g.mean()),lo=float(g.mean()-h),hi=float(g.mean()+h),p=p,npos=int((g>0).sum()))
out={}
Rb=np.array([max(f[0][s] for f in fam) for s in range(10)]);print('best DLQR per road mean',Rb.mean(),'range',Rb.min(),Rb.max())
for k in ['PID','Fuzzy','FPID','LQR']:
    th=json.load(open('rev_t6m_%s.json'%k))['theta'];R=[];F=[]
    for z,a in zip(TE,A0):
        m=met(simulate(k,th,z,P2d,P2),P2d);R.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
    out[k]=dict(red=float(np.mean(R)),F=float(np.mean(F)),gap=gaps(np.array(R),np.array(F)));print(k,out[k],flush=True)
bi=max(range(len(fam)),key=lambda i:fam[i][0].mean());print('best family point',fam[bi][0].mean(),fam[bi][1].mean())
out['best_dlqr']=dict(red=float(fam[bi][0].mean()),F=float(fam[bi][1].mean()),maxroad=float(Rb.mean()))
json.dump(out,open('rev_dlqr_gap.json','w'),indent=1)
