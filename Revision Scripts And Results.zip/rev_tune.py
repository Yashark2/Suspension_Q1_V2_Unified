import numpy as np, pickle, json, inspect, time, sys
import mirror
from mirror import *
from scipy.optimize import minimize
TH=dict(PID=[2.32,2.747,-2.99],Fuzzy=[-0.1535,-0.4699,2.621],FPID=[2.446,2.45,-2.393,2.261,0.26],LQR=[4.503,4.446],L1=[1.877,-3.0])
INIT=dict(PID=[2.5,2.5,-3],Fuzzy=[0.3,-0.7,2.5],FPID=[2.5,2.5,-3,1,1],LQR=[4.58,4.48])
src=inspect.getsource(simulate).replace("rec=True):","rec=True,g=1.0):").replace("def simulate(","def sim2(").replace("x=Ad@x+Bd*Fl+Ed*zr[k]","x=Ad@x+Bd*g*Fl+Ed*zr[k]").replace("Fa[k]=Fl;","Fa[k]=g*Fl;")
exec(src,globals())
def pert(**k):
    p=dict(P)
    for a,b in k.items():p[a]=P[a]*b
    return p
zB=iso_road('B',11,8.)[1];zD=iso_road('D',12,8.)[1]
scen=[(zB,P),(zD,pert(ms=1.2,ks=0.8,cs=0.7,kt=0.85)),(zB,pert(ms=0.8,ks=1.2,cs=1.2,kt=1.1))]
base=[met(simulate('Passive',[0],z,p,P),p) for z,p in scen]
def J(th,kind,g=1.0):
    tot=0
    for (z,p),b in zip(scen,base):
        d=sim2(kind,th,z,p,P,g=g)
        if d is None:return 1e3
        m=met(d,p)
        tot+=m['aw']/b['aw']+.5*m['tire']/b['tire']+.3*m['susp']/b['susp']+0.2*m['rmsF']/P['Fmax']+10*max(0,m['maxs']/0.08-1)
    return tot/len(scen)
out={}
mirror.LQRK=lqr_out(P,10**4.503,10**4.446)
part=sys.argv[1]
if part=='gain':
    out['Jgain']={}
    for k in ['PID','Fuzzy','FPID','LQR','L1']:
        out['Jgain'][k]={str(g):J(TH[k],k,g) for g in (1.0,0.85,0.7,0.5)};print(k,out['Jgain'][k],flush=True)
if part=='multi':
    TE=[iso_road('C',s,10.)[1] for s in (31,32,33,34,35)]
    aP=[met(simulate('Passive',[0],z,P,P),P)['aw'] for z in TE]
    def test(k,th):
        r=[];F=[]
        for z,a in zip(TE,aP):
            d=simulate(k,th,z,P,P)
            if d is None:return None
            m=met(d,P);r.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
        return float(np.mean(r)),float(np.mean(F))
    rng=np.random.default_rng(7);out['multi']={}
    for k in ['PID','Fuzzy','LQR','FPID']:
        rows=[dict(start='tuned(reference)',J=J(TH[k],k),test=test(k,TH[k]),th=TH[k])]
        for i in range(4):
            x0=np.array(INIT[k],float)+rng.normal(0,0.3,len(INIT[k]))
            if k=='FPID':x0[3:]=np.abs(np.array(INIT[k][3:])*np.exp(rng.normal(0,0.3,2)))
            r=minimize(J,x0,args=(k,),method='Nelder-Mead',options=dict(maxfev=60,xatol=1e-2,fatol=1e-3))
            rows.append(dict(start=i,J0=J(x0,k),J=float(r.fun),test=test(k,list(r.x)),th=list(map(float,r.x))))
            print(k,rows[-1],flush=True)
        out['multi'][k]=rows
if part=='delay':
    P20=dict(P);P20['tau_d']=0.02
    TR=[iso_road('C',s,10.)[1] for s in (21,22)];TE=[iso_road('C',s,10.)[1] for s in (24,25,26)]
    def retune(kind,x0):
        def Jr(x):
            v=[]
            for z in TR:
                a0=met(simulate('Passive',[0],z,P20,P),P20)['aw'];dd=simulate(kind,x,z,P20,P)
                if dd is None:return 1e3
                m=met(dd,P20);v.append(m['aw']/a0+1e-4*m['rmsF'])
            return float(np.mean(v))
        return minimize(Jr,x0,method='Nelder-Mead',options=dict(maxfev=30,xatol=1e-2,fatol=1e-4)).x
    def ev(kind,th,lqrth=None):
        mirror.LQRK=lqr_out(P,10**(lqrth or TH['LQR'])[0],10**(lqrth or TH['LQR'])[1])
        R=[];F=[];T=[];S=[]
        for z in TE:
            pa=simulate('Passive',[0],z,P20,P);ma=met(pa,P20);d=simulate(kind,th,z,P20,P)
            if d is None:return None
            m=met(d,P20);R.append(100*(ma['aw']-m['aw'])/ma['aw']);F.append(m['rmsF']);T.append(m['tire']/ma['tire']);S.append(m['susp']/ma['susp'])
        return dict(red=float(np.mean(R)),F=float(np.mean(F)),tire=float(np.mean(T)),susp=float(np.mean(S)))
    old=json.load(open('final_items.json'))['delay']
    out['d']={}
    for k in ['PID','Fuzzy','LQR','FPID']:
        th_r=old[k]['theta'] if k in old else list(retune(k,TH[k]))
        out['d'][k]=dict(untuned=ev(k,TH[k]),retuned=ev(k,th_r),theta=th_r);print(k,out['d'][k],flush=True)
    lq=out['d']['LQR']['theta']
    out['d']['L1_untuned']=ev('L1',TH['L1']);out['d']['L1_ret_b1.5N']=ev('L1',TH['L1'],lq);out['d']['L1_ret_b150N']=ev('L1',[1.877,-1.0],lq)
    print(out['d']['L1_untuned'],out['d']['L1_ret_b1.5N'],out['d']['L1_ret_b150N'])
json.dump(out,open('rev_tune_%s.json'%part,'w'),indent=1)
