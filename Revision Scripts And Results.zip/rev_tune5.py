"""Larger-budget re-tuning. usage: rev_tune5.py delay|plant2 KIND BUDGET
delay : 20 ms sensor delay, cost a_w/a_w^P + 1e-4*F, trained on seeds 21,22, tested on seeds 24-33; starts: 5 ms gains and the earlier 30-evaluation result
plant2: second parameter set (ms=300, mu=40, ks=16000, cs=1000, kt=160000), design model = plant, same 3-scenario cost as Section 4.2, two starts."""
import sys, json, os, numpy as np, mirror
from mirror import *
from scipy.optimize import minimize
part,kind,budget=sys.argv[1],sys.argv[2],int(sys.argv[3])
TH=dict(PID=[2.32,2.747,-2.99],Fuzzy=[-0.1535,-0.4699,2.621],FPID=[2.446,2.45,-2.393,2.261,0.26],LQR=[4.503,4.446],L1=[1.877,-3.0])
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000)
def pert(Pn,**k):
    p=dict(Pn)
    for a,b in k.items():p[a]=Pn[a]*b
    return p
def nm(J,x0,n):
    r=minimize(J,x0,method='Nelder-Mead',options=dict(maxfev=n,xatol=1e-2,fatol=1e-4));return list(map(float,r.x)),float(r.fun)
out=dict(kind=kind,budget=budget,part=part)
if part=='delay':
    P20=dict(P);P20['tau_d']=0.02
    if kind=='L1':
        lq=json.load(open('rev_t5_delay_LQR.json'))['theta'];mirror.LQRK=lqr_out(P,10**lq[0],10**lq[1])
    TR=[iso_road('C',s,10.)[1] for s in (21,22)];TE=[iso_road('C',s,10.)[1] for s in range(24,34)]
    a0=[met(simulate('Passive',[0],z,P20,P),P20)['aw'] for z in TR]
    def Jr(x):
        v=[]
        for z,a in zip(TR,a0):
            d=simulate(kind,x,z,P20,P)
            if d is None:return 1e3
            m=met(d,P20);v.append(m['aw']/a+1e-4*m['rmsF'])
        return float(np.mean(v))
    starts=[TH[kind]]
    if kind=='L1':starts=[[1.877,-3.0],[1.877,-1.0]]
    else:
        old=json.load(open('final_items.json'))['delay']
        if kind in old:starts.append(old[kind]['theta'])
    best=None;out['starts']=[]
    for s0 in starts:
        x,f=nm(Jr,s0,budget);out['starts'].append(dict(x0=s0,x=x,J=f,J0=Jr(s0)))
        if best is None or f<best[1]:best=(x,f)
    out['theta']=best[0];out['J']=best[1]
    def ev(th):
        R=[];F=[];T=[];S=[]
        for z in TE:
            ma=met(simulate('Passive',[0],z,P20,P),P20);m=met(simulate(kind,th,z,P20,P),P20)
            R.append(100*(ma['aw']-m['aw'])/ma['aw']);F.append(m['rmsF']);T.append(m['tire']/ma['tire']);S.append(m['susp']/ma['susp'])
        return dict(R=R,F=F,T=T,S=S)
    out['test_retuned']=ev(out['theta']);out['test_5ms_gains']=ev(TH[kind]) if kind!='L1' else None
if part=='plant2':
    Pn=P2;rng=np.random.default_rng({'PID':51,'Fuzzy':52,'FPID':53,'LQR':54}.get(kind,55))
    if kind=='L1':raise SystemExit
    zB=iso_road('B',11,8.)[1];zD=iso_road('D',12,8.)[1]
    scen=[(zB,Pn),(zD,pert(Pn,ms=1.2,ks=0.8,cs=0.7,kt=0.85)),(zB,pert(Pn,ms=0.8,ks=1.2,cs=1.2,kt=1.1))]
    base=[met(simulate('Passive',[0],z,p,Pn),p) for z,p in scen]
    def J(th):
        tot=0
        for (z,p),b in zip(scen,base):
            d=simulate(kind,th,z,p,Pn)
            if d is None:return 1e3
            m=met(d,p);tot+=m['aw']/b['aw']+.5*m['tire']/b['tire']+.3*m['susp']/b['susp']+0.2*m['rmsF']/Pn['Fmax']+10*max(0,m['maxs']/0.08-1)
        return tot/len(scen)
    x0=np.array(TH[kind],float);starts=[list(x0)]
    s2=x0+rng.normal(0,0.3,len(x0))
    if kind=='FPID':s2[3:]=np.abs(x0[3:]*np.exp(rng.normal(0,0.3,2)))
    starts.append(list(s2));best=None;out['starts']=[]
    for s0 in starts:
        x,f=nm(J,s0,budget);out['starts'].append(dict(x0=s0,x=x,J=f,J0=J(s0)))
        if best is None or f<best[1]:best=(x,f)
    out['theta']=best[0];out['J']=best[1]
json.dump(out,open('rev_t5_%s_%s.json'%(part,kind),'w'),indent=1);print('done',kind,out.get('theta'),out.get('J'))
