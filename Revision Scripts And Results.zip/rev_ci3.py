import pickle,json,numpy as np
from scipy import stats
rows=pickle.load(open('rev_ci2.pkl','rb'));res=json.load(open('rev_ci_B.json'))
def env(pts):
    P=np.array(pts);P=P[np.argsort(P[:,1])];F=[0.];R=[0.];b=0
    for r,f in P:
        if r>b:b=r;F.append(f);R.append(r)
    return np.array(F),np.array(R)
out={}
for k in ['PID','Fuzzy','FPID','LQR']:
    R=np.array(res[k]['R']);F=np.array(res[k]['F']);g=[]
    for s in range(10):
        Fe,Re=env([(r[0][s],r[1][s]) for r in rows]);g.append(R[s]-np.interp(F[s],Fe,Re))
    g=np.array(g);se=g.std(ddof=1)/np.sqrt(10);t=stats.t.ppf(.975,9)
    try:p=float(stats.wilcoxon(g).pvalue)
    except Exception:p=float('nan')
    out[k]=dict(mean=float(g.mean()),sd=float(g.std(ddof=1)),lo=float(g.mean()-t*se),hi=float(g.mean()+t*se),p=p,npos=int((g>0).sum()),gaps=g.tolist())
    print(k,round(R.mean(),2),round(F.mean(),1),'same-seed gap',round(g.mean(),2),round(g.mean()-t*se,2),round(g.mean()+t*se,2),'p',round(p,3),'npos',(g>0).sum())
json.dump(out,open('rev_ci_same.json','w'),indent=1)
for fn in 'AB':
    for k in ['PID','Fuzzy','FPID','LQR']:
        d=res[k]['gap_'+fn];print(fn,k,round(d['mean'],2),round(d['lo'],2),round(d['hi'],2),round(d['p'],3),d['npos'])
