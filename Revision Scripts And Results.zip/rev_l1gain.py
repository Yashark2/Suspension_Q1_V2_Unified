import numpy as np, inspect, json, mirror
from mirror import *
mirror.LQRK=lqr_out(P,10**4.503,10**4.446)
src=inspect.getsource(simulate).replace("rec=True):","rec=True,g=1.0):").replace("def simulate(","def sim2(").replace("x=Ad@x+Bd*Fl+Ed*zr[k]","x=Ad@x+Bd*g*Fl+Ed*zr[k]").replace("Fa[k]=Fl;","Fa[k]=g*Fl;")
exec(src,globals())
R=[iso_road('C',s,10.)[1] for s in (21,22,23)]
aP=[met(simulate('Passive',[0],z,P,P),P)['aw'] for z in R]
out={}
for nm,k,th in [('LQR','LQR',[4.503,4.446]),('L1 1.5N','L1',[1.877,-3.0]),('L1 150N','L1',[1.877,-1.0]),('L1 lowbw 150N','L1',[1.0,-1.0])]:
    out[nm]={}
    for g in (1.0,0.7,0.5):
        r=[];F=[]
        for z,a in zip(R,aP):
            d=sim2(k,th,z,P,P,g=g);m=met(d,P);r.append(100*(a-m['aw'])/a);F.append(m['rmsF'])
        out[nm][g]=(float(np.mean(r)),float(np.mean(F)))
    print(nm,out[nm],flush=True)
json.dump({k:{str(g):v for g,v in d.items()} for k,d in out.items()},open('rev_l1gain.json','w'))
