"""Delay-aware LQR (state predictor over the 20 ms delay using the known actuator model) on the SECOND plant,
and force-matched comparison against it. usage: rev_dlqr.py time | tune | family"""
import sys, json, numpy as np, mirror
from mirror import *
from scipy import stats
from scipy.optimize import minimize
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000);P2d=dict(P2);P2d['tau_d']=0.02
A,b,E=mats(P2);dt=P2['dt'];Ad,Bd,Ed=c2d(A,b,E,dt);nd=int(round(P2d['tau_d']/dt));al=dt/(P2['tau_a']+dt)
def sim(th,z,g=1.0,Pp=P2d):
    K=g*lqr_out(P2,10**th[0],10**th[1]);N=len(z);X=np.zeros((N,4));Fa=np.zeros(N);Us=np.zeros(N);x=np.zeros(4);Fr=0.;Fl=0.
    for k in range(N):
        X[k]=x
        if k>=nd:
            xp=X[k-nd].copy();fr=fl=Fa[k-nd]
            for j in range(k-nd,k):
                # measured past forces are not available beyond k-nd: rebuild them from own commands
                if j>k-nd:
                    fr=fr+np.clip(Us[j-1]-fr,-P2['dFmax']*dt,P2['dFmax']*dt);fl=fl+al*(fr-fl)
                    xp=Ad@xp+Bd*fl
                else:
                    xp=Ad@xp+Bd*Fa[j]
            u=-K@xp
        else:u=0.
        us=float(np.clip(u,-P2['Fmax'],P2['Fmax']));Us[k]=us
        Fr=Fr+np.clip(us-Fr,-P2['dFmax']*dt,P2['dFmax']*dt);Fl+=al*(Fr-Fl);Fa[k]=Fl;x=Ad@x+Bd*Fl+Ed*z[k]
        if not np.all(np.isfinite(x)) or np.abs(x).max()>5:return None
    zs,zsd,zu,zud=X.T;a=(-P2['ks']*(zs-zu)-P2['cs']*(zsd-zud)+Fa)/P2['ms']
    return dict(t=np.arange(N)*dt,zs=zs,zsd=zsd,zu=zu,zud=zud,F=Fa,Fc=Us,a=a,susp=zs-zu,tire=zu-z)
def red(th,z,a0,g=1.0):
    d=sim(th,z,g)
    if d is None:return -100.,1e4,None
    m=met(d,P2d);return 100*(a0-m['aw'])/a0,m['rmsF'],m
if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='time':
        import time;z=iso_road('C',21,10.)[1];a0=met(simulate('Passive',[0],z,P2d,P2),P2d)['aw'];t=time.time()
        for th in ([3.26,4.74],[3,5],[1,5]):print(th,red(th,z,a0)[:2],time.time()-t,flush=True)
    if mode=='tune':
        st=json.loads(sys.argv[2]);tag=sys.argv[3]
        TR=[iso_road('C',s_,10.)[1] for s_ in (21,22)];a0=[met(simulate('Passive',[0],z,P2d,P2),P2d)['aw'] for z in TR]
        def J(x):
            x=np.clip(x,-2,8);v=[]
            for z,a in zip(TR,a0):
                r,F,_=red(x,z,a);v.append((100-r)/100+1e-4*F)
            return float(np.mean(v))
        r=minimize(J,st,method='Nelder-Mead',options=dict(maxfev=70,xatol=1e-2,fatol=1e-4));x=list(map(float,np.clip(r.x,-2,8)))
        json.dump(dict(x0=st,x=x,J=float(r.fun),J0=J(st)),open('rev_dlqr_tune_%s.json'%tag,'w'));print(tag,x,r.fun,flush=True)
    if mode=='family':
        idx=int(sys.argv[2]);pairs=[[3.69,4.08],[3.0,4.0],[4.0,4.5],[2.0,3.5],[3.69,5.0],[3.0,5.5]]
        TE=[iso_road('C',s_,10.)[1] for s_ in range(24,34)];A0=[met(simulate('Passive',[0],z,P2d,P2),P2d)['aw'] for z in TE];out=[]
        for p in pairs[idx::2]:
            for g in (0.5,0.8,1.0,1.3,1.8,2.5):
                R=[];F=[]
                for z,a in zip(TE,A0):
                    r,f,_=red(p,z,a,g);R.append(r);F.append(f)
                out.append(dict(p=p,g=g,R=R,F=F));print(p,g,round(np.mean(R),2),round(np.mean(F)),flush=True)
                json.dump(out,open('rev_dlqr_fam_%d.json'%idx,'w'))
