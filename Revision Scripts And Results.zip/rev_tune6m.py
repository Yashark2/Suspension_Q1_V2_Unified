"""Re-tuning on the SECOND plant with 20 ms sensor delay, bounded parameters.
usage: rev_tune6.py KIND BUDGET   (KIND: PID Fuzzy FPID LQR L1)
cost: a_w/a_w^passive + 1e-4*rmsF on ISO C seeds 21,22; test seeds 24-33. Fuzzy output amplitude bounded to log10(Fmax)."""
import sys, json, numpy as np, mirror
from mirror import *
from scipy.optimize import minimize
kind,budget=sys.argv[1],int(sys.argv[2])
TH=dict(PID=[2.32,2.747,-2.99],Fuzzy=[-0.1535,-0.4699,2.621],FPID=[2.446,2.45,-2.393,2.261,0.26],LQR=[4.503,4.446],L1=[1.877,-3.0])
P2=dict(P);P2.update(ms=300,mu=40,ks=16000,cs=1000,kt=160000);P2d=dict(P2);P2d['tau_d']=0.02
LG=float(np.log10(P['Fmax']))
def bound(x):
    x=np.array(x,float)
    if kind=='Fuzzy':x=np.array([np.clip(x[0],-2,2),np.clip(x[1],-2,2),np.clip(x[2],0,LG)])
    if kind in('PID','FPID'):x[:3]=np.clip(x[:3],-4,5)
    if kind=='FPID':x[3:]=np.clip(x[3:],0,6)
    if kind=='LQR':x=np.clip(x,-2,8)
    if kind=='L1':x=np.array([np.clip(x[0],0,3),np.clip(x[1],-3,0)])
    return x
if kind=='L1':
    lq=json.load(open('rev_t6m_LQR.json'))['theta'];mirror.LQRK=lqr_out(P2,10**lq[0],10**lq[1])
TR=[iso_road('C',s,10.)[1] for s in (21,22)];TE=[iso_road('C',s,10.)[1] for s in range(24,34)]
a0=[met(simulate('Passive',[0],z,P2d,P2),P2d)['aw'] for z in TR]
def Jr(x):
    v=[]
    for z,a in zip(TR,a0):
        d=simulate(kind,bound(x),z,P2d,P2)
        if d is None:return 1e3
        m=met(d,P2d);v.append(m['aw']/a+1e-4*m['rmsF'])
    return float(np.mean(v))
f=np.log10(2.32)
EXTRA=dict(PID=[[1.81+f,2.73+f,0.61+f],[2.5,2.0,0.0]],Fuzzy=[[-0.1,-0.9,1.93],[0.3,-0.3,2.8],[-0.5,-1.2,2.4]],
 FPID=[[1.81,2.73,0.61,2.32,0.58],[2.0,2.0,0.0,1.0,1.0]],LQR=[[3.26,4.73],[2.0,3.0],[5.0,6.0]],L1=[[1.98,-1.41],[1.0,-0.5]])
starts=[TH[kind]]+EXTRA[kind]
if kind=='L1':starts=[[1.877,-3.0]]+EXTRA['L1']
out=dict(kind=kind,budget=budget,starts=[]);best=None
for s0 in starts:
    s0=list(bound(s0));r=minimize(Jr,s0,method='Nelder-Mead',options=dict(maxfev=budget,xatol=1e-2,fatol=1e-4))
    x=list(map(float,bound(r.x)));out['starts'].append(dict(x0=s0,x=x,J=float(Jr(x)),J0=Jr(s0)));print(kind,out['starts'][-1],flush=True)
    if best is None or out['starts'][-1]['J']<best[1]:best=(x,out['starts'][-1]['J'])
out['theta']=best[0];out['J']=best[1]
def ev(th):
    R=[];F=[];T=[];S=[];sat=[]
    for z in TE:
        ma=met(simulate('Passive',[0],z,P2d,P2),P2d);d=simulate(kind,th,z,P2d,P2)
        if d is None:R.append(float('nan'));F.append(float('nan'));T.append(float('nan'));S.append(float('nan'));continue
        m=met(d,P2d);R.append(100*(ma['aw']-m['aw'])/ma['aw']);F.append(m['rmsF']);T.append(m['tire']/ma['tire']);S.append(m['susp']/ma['susp'])
        sat.append(float(np.mean(np.abs(d['Fc'])>=P['Fmax'])))
    return dict(R=R,F=F,T=T,S=S,sat=sat)
out['test_retuned']=ev(out['theta'])
if kind!='L1':out['test_untuned']=ev(TH[kind])
json.dump(out,open('rev_t6m_%s.json'%kind,'w'),indent=1);print('done',kind,out['theta'],out['J'],flush=True)
