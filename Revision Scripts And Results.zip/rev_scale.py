import numpy as np, pickle, inspect, pandas as pd, json
import mirror
from mirror import *
TH=dict(PID=[2.32,2.747,-2.99],Fuzzy=[-0.1535,-0.4699,2.621],FPID=[2.446,2.45,-2.393,2.261,0.26],LQR=[4.503,4.446])
mirror.LQRK=lqr_out(P,10**4.503,10**4.446)
src=inspect.getsource(simulate).replace("rec=True):","rec=True,g=1.0):").replace("def simulate(","def sim2(").replace("x=Ad@x+Bd*Fl+Ed*zr[k]","x=Ad@x+Bd*g*Fl+Ed*zr[k]").replace("Fa[k]=Fl;","Fa[k]=g*Fl;")
exec(src,globals())
D=pickle.load(open('raw.pkl','rb'))['zs']
def road(name):
    r=D.iloc[0].ffill().astype(str).str.lower();cols=[i for i in range(D.shape[1]) if r[i].startswith(name)]
    names=[str(x).lower() for x in D.iloc[1,cols]];b=D.iloc[2:,cols].apply(pd.to_numeric,errors='coerce');b.columns=names
    t=b['time'].values;z=b['road'].values;ok=np.isfinite(t)&np.isfinite(z);t,z=t[ok],z[ok];_,iu=np.unique(t,return_index=True);t,z=t[iu],z[iu]
    tu=np.arange(t[0],t[-1],1e-3);return np.interp(tu,t,z)
G=[0.2,0.3,0.4,0.5,0.6,0.7,0.85,1.0,1.2,1.5]
roads={'ISO_C_21_23':[iso_road('C',s,10.)[1] for s in (21,22,23)],'ISO_C_31_33':[iso_road('C',s,10.)[1] for s in (31,32,33)],'VariableFreq':[road('variable')],'Bump':[road('bump')]}
out={}
for nm,zs in roads.items():
    aP=[met(simulate('Passive',[0],z,P,P),P) for z in zs];out[nm]={}
    for k in ['PID','Fuzzy','FPID','LQR']:
        rows=[]
        for g in G:
            R=[];F=[];T=[];S=[]
            for z,a in zip(zs,aP):
                d=sim2(k,TH[k],z,P,P,g=g)
                if d is None:break
                m=met(d,P);R.append(100*(a['aw']-m['aw'])/a['aw']);F.append(m['rmsF']);T.append(m['tire']/a['tire']);S.append(m['susp']/a['susp'])
            else: rows.append((g,float(np.mean(R)),float(np.mean(F)),float(np.mean(T)),float(np.mean(S))))
        out[nm][k]=rows;print(nm,k,[(r[0],round(r[1],1),round(r[2])) for r in rows],flush=True)
    json.dump(out,open('rev_scale.json','w'))
